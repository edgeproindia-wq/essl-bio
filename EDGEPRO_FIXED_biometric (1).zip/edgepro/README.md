# EDGEPRO – Employee Self Service Portal

## Quick Setup

```bash
# 1. Install Django
pip install django

# 2. Run migrations (creates all tables)
python manage.py migrate

# 3. Create a superuser (HR Admin)
python manage.py createsuperuser

# 4. Run the server
python manage.py runserver

# 5. Open http://127.0.0.1:8000/
```

## Default URLs
- Login: `/login/`
- Register: `/register/`
- Dashboard: `/` (requires login)
- Admin Panel: `/admin/`

## Features (All Functional)
- Dashboard with live stats
- Announcements (create, list, manage, pin/unpin)
- Attendance (Check In/Out, Late Login, Monthly Report)
- Leave Management (Apply, Casual, Sick, History, Summary, TL Approval)
- Payroll (Salary History, Bonus, Payslip)
- Complaint Management (Raise, Track, Resolution, HR Review)
- Recruitment (Job Postings, Resume Upload, Interview Schedule)
- Workflow (Approve/Reject Requests, History, Email Notifications)
- Work Tracking (Daily Update, Time Tracking, Task Assignment, Progress, Projects)
- Employee Profile & Settings

## Notes
- Superusers (is_staff=True) can access HR Admin features
- All form submissions are backed by the database
- The dashboard is a single-page application (SPA) rendered by Django
