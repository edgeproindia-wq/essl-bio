@echo off
REM EDGEPRO Django Setup Script for Windows
REM This script will set up the database and run migrations

echo ============================================
echo EDGEPRO - Automated Setup Script
echo ============================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python is not installed or not in PATH
    echo Please install Python 3.8+ and add it to PATH
    pause
    exit /b 1
)

echo Step 1: Deleting old database...
if exist db.sqlite3 (
    del db.sqlite3
    echo ✓ Old database deleted
) else (
    echo ℹ No old database found (fresh install)
)
echo.

echo Step 2: Cleaning old migrations...
REM Keep __init__.py but delete migration files
for /f %%f in ('dir /b Essportal\migrations\*.py ^| findstr /v __init__') do (
    del Essportal\migrations\%%f
)
echo ✓ Old migrations cleaned
echo.

echo Step 3: Creating fresh migrations...
python manage.py makemigrations
if errorlevel 1 (
    echo ERROR: Failed to create migrations
    pause
    exit /b 1
)
echo ✓ Migrations created successfully
echo.

echo Step 4: Applying migrations to database...
python manage.py migrate
if errorlevel 1 (
    echo ERROR: Failed to apply migrations
    pause
    exit /b 1
)
echo ✓ Migrations applied successfully
echo.

echo Step 5: Creating superuser account...
echo Please enter your admin credentials:
echo.
python manage.py createsuperuser
if errorlevel 1 (
    echo WARNING: Superuser creation failed or was skipped
)
echo.

echo ============================================
echo ✓ Setup Complete!
echo ============================================
echo.
echo To start the Django server, run:
echo   python manage.py runserver
echo.
echo Then visit: http://127.0.0.1:8000/
echo.
pause
