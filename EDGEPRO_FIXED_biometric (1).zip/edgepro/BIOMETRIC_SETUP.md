# eSSL Biometric Integration — Setup Guide

## What was added
- `Essportal/models.py` — `BiometricDevice`, `RawBiometricLog`, `BiometricSyncLog`,
  and `EmployeeProfile.biometric_user_id`
- `Essportal/migrations/0012_biometricdevice_employeeprofile_biometric_user_id_and_more.py`
- `Essportal/biometric_service.py` — punch processing (mapping, dedup, late/OT logic)
- `Essportal/views_biometric.py` — secured sync API + HR troubleshooting view
- `Essportal/admin.py` — registered new models
- `Essportal/urls.py` — `/api/biometric/sync/` and `/attendance/biometric/dashboard/`
- `EDGEPRO/settings.py` — `BIOMETRIC_API_KEY`, shift-time settings, `biometric` logger
- `Essportal/management/commands/link_biometric_ids.py` — name-matching linker
- `biometric_agent/list_device_users.py` — pulls device's enrolled user list
- `biometric_agent/sync_agent.py` — the local sync agent (Windows Task Scheduler job)

Tested end-to-end locally (migration applies cleanly, `manage.py check` passes,
simulated punches correctly created/updated `AttendanceRecord` with late/overtime
detection and duplicate rejection).

## Step-by-step

### 1. Deploy the code
Upload this project to PythonAnywhere (replace your existing files), then in the
PythonAnywhere Bash console:
```bash
cd ~/EDGEPRO_FIXED/edgepro   # or wherever your project lives
python manage.py migrate
```
Then click the green **Reload** button on the Web tab (required after every
Python change — nothing auto-reloads on PythonAnywhere).

### 2. Set your API key
In the PythonAnywhere Web tab → your web app → "Environment variables" section
(or wherever you set env vars — `.env` if you use python-decouple):
```
BIOMETRIC_API_KEY=<a long random string, e.g. from `python -c "import secrets; print(secrets.token_hex(32))"`>
```
This same value must also be set on the office PC in step 4/5. Never leave the
default placeholder value live in production.

### 3. Get the device's enrolled user list
On the **office PC** (same network as the device, IP `192.168.1.39`):
```bash
pip install pyzk openpyxl
cd biometric_agent
python list_device_users.py --ip 192.168.1.39
```
This prints every enrolled User ID + Name and saves `device_users.xlsx`.

### 4. Link device IDs to your employees
Upload `device_users.xlsx` to the Django project folder (or wherever
`manage.py` runs from), then:
```bash
python manage.py link_biometric_ids --file device_users.xlsx --dry-run
```
Review the printed matches. If they look right, run it for real:
```bash
python manage.py link_biometric_ids --file device_users.xlsx
```
Anything "ambiguous" or "no match" is printed separately — those need manual
fixing (e.g. via Django admin, on the `EmployeeProfile` record's
`biometric_user_id` field) because of a spelling mismatch between the device
name and the ESS name.

### 5. Run the sync agent
On the same office PC:
```bash
pip install -r biometric_agent/requirements.txt
python biometric_agent/sync_agent.py --ip 192.168.1.39 \
    --api-url https://edgeproindia.pythonanywhere.com/api/biometric/sync/ \
    --api-key <the BIOMETRIC_API_KEY value from step 2>
```
First run sends all logs currently on the device once; every run after that
only sends new punches (tracked in `biometric_agent/last_synced.txt`).

### 6. Automate it
Windows Task Scheduler → Create Task → Trigger: repeat every 5 minutes →
Action: run `python.exe biometric_agent\sync_agent.py` with the same
`--ip`/`--api-url`/`--api-key` arguments (or set them as environment
variables so they don't need to be typed each time). Tick "Run whether user
is logged on or not."

## Testing
1. Have 2–3 employees punch in/out on the real device.
2. Run `sync_agent.py` manually once and watch the console/`sync_agent.log`.
3. Check Django admin → Raw Biometric Logs — should show the punches,
   `matched=True`, `processed=True`.
4. Check Django admin → Attendance Records — check-in/check-out times should
   match what was punched.
5. Punch again with the same employee at the same second (or re-run the
   agent without new data) — confirm no duplicate rows are created.

## Troubleshooting
- **Agent can't connect to device**: confirm the PC is on the same
  network/VLAN as the device, ping `192.168.1.39` first, check Windows
  Firewall isn't blocking outbound TCP 4370.
- **API returns 401**: `BIOMETRIC_API_KEY` mismatch between PythonAnywhere
  env var and the agent's `--api-key`.
- **Punches arrive but don't show in AttendanceRecord**: check Django admin →
  Raw Biometric Logs for that punch — `matched=False` means the device User
  ID isn't linked yet (go back to step 4); `error_message` will explain why.
- **Wrong late/overtime flags**: adjust `BIOMETRIC_OFFICE_START`,
  `BIOMETRIC_OFFICE_END`, `BIOMETRIC_LATE_GRACE_MINUTES` etc. in
  `EDGEPRO/settings.py` to match your actual shift timing.

## Security notes
- The sync endpoint is CSRF-exempt (machine-to-machine) but requires the
  `X-Biometric-Api-Key` header — treat that key like a password.
- Always run production over HTTPS (PythonAnywhere gives you this by
  default) so the API key isn't sent in plaintext.
- Consider IP-restricting the endpoint at the PythonAnywhere/network level
  to your office's public IP, if it's static.

## Multi-device support (future)
`BiometricDevice` already supports multiple rows — to add a second device,
just run `list_device_users.py` / `sync_agent.py` on that device's network
with its own `--ip`, and the sync endpoint auto-registers new devices by IP
on first call. No code changes needed.
