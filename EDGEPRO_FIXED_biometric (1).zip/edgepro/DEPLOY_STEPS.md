# EDGEPRO — Deployment Checklist (Read This First)

Your code was already written with production settings in mind (SECRET_KEY,
DEBUG, and ALLOWED_HOSTS all read from environment variables). Nothing in
`settings.py` needs manual editing. What was missing has now been added:

## What was added in this package
1. **`.env.example`** — every environment variable you need, with a real
   freshly-generated `DJANGO_SECRET_KEY` already filled in.
2. **`build.sh`** — one script that installs dependencies, collects static
   files, and runs migrations. Use this as your platform's "Build Command".
3. **`Procfile`** — updated so `collectstatic` always runs before `migrate`
   on deploy (fixes CSS/JS not loading).
4. **`runtime.txt`** — updated to Python 3.11.9 (3.8 is end-of-life).

## Steps to go live (Render example)

1. Push this whole folder to your GitHub repo (root level — `manage.py`,
   `requirements.txt`, `Procfile` must all sit directly in the repo root,
   not inside a subfolder).
2. In Render dashboard → your service → **Environment**:
   - Copy every line from `.env.example` into Render's environment
     variables (except the DATABASE_URL comment — Render sets that
     automatically if you attach a Postgres database).
   - Replace `yourdomain.com` with your real domain.
3. In Render → **Settings** → Build Command:
   ```
   ./build.sh
   ```
4. In Render → **Settings** → Start Command:
   ```
   gunicorn EDGEPRO.wsgi:application --bind 0.0.0.0:$PORT
   ```
5. Attach a **Postgres** database (Render → New → PostgreSQL, then link it
   to this service) — SQLite is fine for testing but not for real
   employee/payroll data.
6. Deploy. Watch the build logs — if `requirements.txt` errors show up
   again, it means the repo root is wrong (see step 1).
7. Once live, connect your custom domain in Render → **Settings** →
   **Custom Domains**, then add the CNAME record it gives you at your
   domain registrar.

## Steps to go live (PythonAnywhere example)

1. Upload/clone this project into your PythonAnywhere account.
2. Open a Bash console:
   ```bash
   pip install -r requirements.txt --user
   python manage.py collectstatic --noinput
   python manage.py migrate
   ```
3. In the **Web** tab → **Environment variables** section, add each
   variable from `.env.example`.
4. Point the WSGI config file to `EDGEPRO.wsgi.application`.
5. Set your custom domain via the pencil icon next to the app name (paid
   plan required), then add the CNAME PythonAnywhere gives you at your
   registrar.
6. Reload the web app.

## Final checklist before calling it "live"
- [ ] `DJANGO_DEBUG=False` is set
- [ ] `DJANGO_SECRET_KEY` is set to the value in `.env.example` (or your own)
- [ ] `DJANGO_ALLOWED_HOSTS` includes your real domain
- [ ] Database is Postgres, not SQLite (for real data safety)
- [ ] `collectstatic` has run at least once (CSS/JS loads correctly)
- [ ] Site loads over `https://` (not just `http://`)
