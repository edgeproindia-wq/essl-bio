from .models import Notification
from .permissions import get_user_role, is_hr_or_admin


def portal_context(request):
    if not request.user.is_authenticated:
        return {}
    unread = Notification.objects.filter(user=request.user, is_read=False).count()
    recent_notifications = Notification.objects.filter(user=request.user, is_read=False)[:5]
    return {
        'user_role': get_user_role(request.user),
        'is_hr_admin': is_hr_or_admin(request.user),
        'unread_notifications': unread,
        'recent_notifications': recent_notifications,
    }
