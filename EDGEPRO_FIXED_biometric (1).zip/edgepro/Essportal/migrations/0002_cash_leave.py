from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('Essportal', '0001_initial'),
    ]

    operations = [
        # Add cash_total and cash_used to LeaveBalance
        migrations.AddField(
            model_name='leavebalance',
            name='cash_total',
            field=models.IntegerField(default=6),
        ),
        migrations.AddField(
            model_name='leavebalance',
            name='cash_used',
            field=models.IntegerField(default=0),
        ),
        # Add 'cash' to LeaveApplication.leave_type choices
        # (choices are validated at the Python level; no DB change needed,
        #  but we alter the field to record the new choice list in migration state)
        migrations.AlterField(
            model_name='leaveapplication',
            name='leave_type',
            field=models.CharField(
                max_length=20,
                choices=[
                    ('casual', 'Casual Leave'),
                    ('sick', 'Sick Leave'),
                    ('earned', 'Earned Leave'),
                    ('emergency', 'Emergency Leave'),
                    ('maternity', 'Maternity/Paternity Leave'),
                    ('comp_off', 'Compensatory Off'),
                    ('cash', 'Cash Leave'),
                ],
            ),
        ),
    ]
