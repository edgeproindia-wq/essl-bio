from django.db import migrations, models
from django.utils import timezone


def activate_all_employee_accounts(apps, schema_editor):
    EmployeeProfile = apps.get_model('Essportal', 'EmployeeProfile')
    EmployeeProfile.objects.exclude(registration_status='approved').update(
        registration_status='approved',
        approved_at=timezone.now(),
    )


class Migration(migrations.Migration):

    dependencies = [
        ('Essportal', '0005_employeeprofile_education_cert_uploaded_and_more'),
    ]

    operations = [
        migrations.AlterField(
            model_name='employeeprofile',
            name='registration_status',
            field=models.CharField(
                choices=[
                    ('pending', 'Pending Approval'),
                    ('approved', 'Approved'),
                    ('rejected', 'Rejected'),
                ],
                default='approved',
                max_length=10,
            ),
        ),
        migrations.RunPython(activate_all_employee_accounts, migrations.RunPython.noop),
    ]
