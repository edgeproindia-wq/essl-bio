from django.db import migrations
from django.utils import timezone


def approve_existing_employees(apps, schema_editor):
    """All profiles created before this migration (pre-existing users) are auto-approved."""
    EmployeeProfile = apps.get_model('Essportal', 'EmployeeProfile')
    EmployeeProfile.objects.filter(registration_status='pending').update(
        registration_status='approved',
        approved_at=timezone.now(),
    )


class Migration(migrations.Migration):

    dependencies = [
        ('Essportal', '0003_employee_registration_status'),
    ]

    operations = [
        migrations.RunPython(approve_existing_employees, migrations.RunPython.noop),
    ]
