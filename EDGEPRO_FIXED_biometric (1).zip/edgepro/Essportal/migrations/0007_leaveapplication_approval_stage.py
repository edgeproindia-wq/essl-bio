from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('Essportal', '0006_auto_approve_employee_registrations'),
    ]

    operations = [
        migrations.AddField(
            model_name='leaveapplication',
            name='approval_stage',
            field=models.CharField(
                choices=[('tl', 'Awaiting Team Leader'), ('hr', 'Awaiting HR'), ('done', 'Completed')],
                default='tl',
                max_length=10,
            ),
        ),
        migrations.AddField(
            model_name='leaveapplication',
            name='tl_approver',
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name='tl_leave_approvals',
                to=settings.AUTH_USER_MODEL,
            ),
        ),
        migrations.AddField(
            model_name='leaveapplication',
            name='tl_approved_at',
            field=models.DateTimeField(blank=True, null=True),
        ),
    ]
