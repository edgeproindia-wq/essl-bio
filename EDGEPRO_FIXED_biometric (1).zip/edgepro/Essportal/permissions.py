"""Role-based access control for ESS Portal."""
from functools import wraps

from django.contrib import messages
from django.shortcuts import redirect

from .models import EmployeeProfile


def get_user_role(user):
    if not user.is_authenticated:
        return 'guest'
    if user.is_superuser:
        return 'admin'
    if user.is_staff:
        return 'hr'
    return 'employee'


def is_hr_or_admin(user):
    return user.is_authenticated and (user.is_staff or user.is_superuser)


def is_team_leader(user):
    if not user.is_authenticated:
        return False
    return EmployeeProfile.objects.filter(reporting_manager=user).exists()


def get_dashboard_page(user):
    role = get_user_role(user)
    return {'admin': 'dashboard', 'hr': 'dashboard', 'employee': 'dashboard'}.get(role, 'dashboard')


def can_approve_leave_at_stage(user, leave_app):
    """TL approves at 'tl' stage; HR approves at 'hr' stage."""
    if not user.is_authenticated or leave_app.status != 'pending':
        return False
    if leave_app.approval_stage == 'tl':
        try:
            manager = leave_app.employee.profile.reporting_manager
            if manager and user == manager:
                return True
        except Exception:
            pass
        return is_hr_or_admin(user)
    if leave_app.approval_stage == 'hr':
        return is_hr_or_admin(user)
    return False


def hr_admin_required(view_func):
    @wraps(view_func)
    def _wrapped(request, *args, **kwargs):
        if not getattr(request.user, 'is_authenticated', False):
            return redirect('login')
        if not is_hr_or_admin(request.user):
            messages.error(request, 'Access denied. HR or Admin privileges required.')
            return redirect('dashboard')
        return view_func(request, *args, **kwargs)
    return _wrapped


def hr_admin_required_cbv(method):
    @wraps(method)
    def _wrapped(self, request, *args, **kwargs):
        if not is_hr_or_admin(request.user):
            messages.error(request, 'Access denied. HR or Admin privileges required.')
            return redirect('dashboard')
        return method(self, request, *args, **kwargs)
    return _wrapped
