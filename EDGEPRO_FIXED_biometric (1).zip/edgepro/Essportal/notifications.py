"""Notification service: in-app, email, and push delivery."""
import json
import logging

from django.conf import settings
from django.contrib.auth.models import User
from django.core.mail import send_mail
from django.db.models import Q

from .models import Notification, NotificationPreference

logger = logging.getLogger(__name__)


def _get_or_create_prefs(user):
    prefs, _ = NotificationPreference.objects.get_or_create(user=user)
    return prefs


def create_notification(user, title, message, category='general', link='', send_email=True, send_push=True):
    """Create in-app notification and optionally send email/push."""
    notif = Notification.objects.create(
        user=user,
        title=title,
        message=message,
        category=category,
        link=link,
    )
    prefs = _get_or_create_prefs(user)

    if send_email and prefs.email_enabled and user.email:
        try:
            send_mail(
                subject=f'[EDGEPRO ESS] {title}',
                message=message,
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[user.email],
                fail_silently=not settings.DEBUG,
            )
            notif.email_sent = True
            notif.save(update_fields=['email_sent'])
        except Exception as exc:
            logger.warning('Email notification failed for %s: %s', user.username, exc)

    if send_push and prefs.push_enabled:
        try:
            _send_push_notification(user, title, message, link)
            notif.push_sent = True
            notif.save(update_fields=['push_sent'])
        except Exception as exc:
            logger.warning('Push notification failed for %s: %s', user.username, exc)

    return notif


def notify_users(users, title, message, category='general', link='', send_email=True, send_push=True):
    for user in users:
        create_notification(user, title, message, category, link, send_email, send_push)


def notify_all_employees(title, message, category='announcement', link='', exclude_staff=False):
    qs = User.objects.filter(is_active=True)
    if exclude_staff:
        qs = qs.filter(is_staff=False, is_superuser=False)
    notify_users(qs, title, message, category, link)


def notify_hr_admins(title, message, category='general', link=''):
    users = User.objects.filter(is_active=True).filter(Q(is_staff=True) | Q(is_superuser=True))
    notify_users(users, title, message, category, link)


def notify_team_leader(employee, title, message, category='general', link=''):
    """Notify the employee's reporting manager; fall back to HR if none assigned."""
    try:
        manager = employee.profile.reporting_manager
        if manager and manager.is_active:
            create_notification(manager, title, message, category, link)
            return manager
    except Exception:
        pass
    notify_hr_admins(title, message, category, link)
    return None


def _send_push_notification(user, title, message, link=''):
    """Log push delivery; integrate FCM/APNs via push_token in production."""
    prefs = _get_or_create_prefs(user)
    if prefs.push_token:
        payload = {'title': title, 'message': message, 'link': link}
        logger.info('Push to %s token=%s payload=%s', user.username, prefs.push_token[:20], json.dumps(payload))
    else:
        logger.info('Push queued for %s (no device token): %s', user.username, title)

