"""
biometric_service.py
─────────────────────
Core processing logic for eSSL biometric attendance integration.

Flow:
    Device --> sync agent (pyzk, runs on office PC) --> views_biometric.py (API)
            --> biometric_service.ingest_punches()  [THIS FILE]
            --> RawBiometricLog (raw audit copy)  +  AttendanceRecord (processed)

This file never talks to the device directly — it only processes punch data
that has already been received by the API view. That keeps device I/O
(network, timeouts, retries) fully separate from attendance business logic,
so it can be unit-tested without a real device.
"""
import logging
from datetime import datetime, timedelta, time as dt_time

from django.conf import settings
from django.db import transaction
from django.utils import timezone as tz

from .models import (
    AttendanceRecord,
    BiometricDevice,
    BiometricSyncLog,
    EmployeeProfile,
    RawBiometricLog,
)

logger = logging.getLogger('biometric')

# ── Configurable shift rules (override in settings.py if needed) ──────────────
OFFICE_START_TIME = getattr(settings, 'BIOMETRIC_OFFICE_START', dt_time(9, 0))
OFFICE_END_TIME = getattr(settings, 'BIOMETRIC_OFFICE_END', dt_time(18, 0))
LATE_GRACE_MINUTES = getattr(settings, 'BIOMETRIC_LATE_GRACE_MINUTES', 10)
EARLY_LOGOUT_GRACE_MINUTES = getattr(settings, 'BIOMETRIC_EARLY_LOGOUT_GRACE_MINUTES', 15)
OVERTIME_AFTER_MINUTES = getattr(settings, 'BIOMETRIC_OT_AFTER_MINUTES', 30)  # OT starts 30 min after shift end


class PunchProcessingError(Exception):
    """Raised for punch-level errors that should be logged but not crash the batch."""


def get_or_create_employee_mapping(device_user_id):
    """
    Resolve a device User ID to a Django User via EmployeeProfile.biometric_user_id.
    Returns the User instance, or None if unmapped.
    """
    device_user_id = str(device_user_id).strip()
    try:
        profile = EmployeeProfile.objects.select_related('user').get(
            biometric_user_id=device_user_id
        )
        return profile.user
    except EmployeeProfile.DoesNotExist:
        return None


@transaction.atomic
def ingest_punches(device: BiometricDevice, punches, sync_log: BiometricSyncLog = None):
    """
    Main entry point. `punches` is a list of dicts:
        {"user_id": "74", "timestamp": datetime, "punch_type": "0"}  (punch_type optional)

    For every punch:
      1. Write to RawBiometricLog (permanent, unprocessed copy) — skip if an
         identical (device, user_id, timestamp, punch_type) row already exists
         (DB unique_together is the hard guarantee; we also check first to
         avoid noisy IntegrityErrors and to count duplicates cleanly).
      2. Map device_user_id -> employee. If unmapped, mark matched=False and
         move on (does not block other punches).
      3. Apply to AttendanceRecord for that employee+date (check-in if none
         exists yet for the day, otherwise treat as check-out / update).

    Returns a summary dict: received, matched, unmatched, duplicate, errors.
    """
    summary = {'received': 0, 'matched': 0, 'unmatched': 0, 'duplicate': 0, 'errors': 0}

    for punch in punches:
        summary['received'] += 1
        try:
            device_user_id = str(punch['user_id']).strip()
            punch_time = punch['timestamp']
            if isinstance(punch_time, str):
                punch_time = datetime.fromisoformat(punch_time)
            if tz.is_naive(punch_time):
                punch_time = tz.make_aware(punch_time, tz.get_current_timezone())
            punch_type = str(punch.get('punch_type', 'unknown'))

            # ── Duplicate guard (application-level, DB unique_together backs it up) ──
            already_exists = RawBiometricLog.objects.filter(
                device=device,
                device_user_id=device_user_id,
                punch_time=punch_time,
                punch_type=punch_type,
            ).exists()
            if already_exists:
                summary['duplicate'] += 1
                continue

            employee = get_or_create_employee_mapping(device_user_id)

            raw_log = RawBiometricLog.objects.create(
                device=device,
                device_user_id=device_user_id,
                punch_time=punch_time,
                punch_type=punch_type,
                raw_payload=str(punch),
                employee=employee,
                matched=employee is not None,
            )

            if employee is None:
                summary['unmatched'] += 1
                raw_log.error_message = f"No employee found with biometric_user_id='{device_user_id}'"
                raw_log.save(update_fields=['error_message'])
                logger.warning(
                    "Unmatched biometric punch: device=%s user_id=%s time=%s",
                    device.name, device_user_id, punch_time,
                )
                continue

            summary['matched'] += 1
            _apply_punch_to_attendance(employee, punch_time, raw_log)

        except Exception as exc:  # noqa: BLE001 - must never let one bad punch kill the batch
            summary['errors'] += 1
            logger.exception("Failed to process punch: %s", punch)

    if sync_log:
        sync_log.records_received = summary['received']
        sync_log.records_matched = summary['matched']
        sync_log.records_unmatched = summary['unmatched']
        sync_log.records_duplicate = summary['duplicate']
        sync_log.save(update_fields=[
            'records_received', 'records_matched', 'records_unmatched', 'records_duplicate'
        ])

    return summary


def _apply_punch_to_attendance(employee, punch_time, raw_log: RawBiometricLog):
    """
    Decide whether this punch is a check-in or check-out for the day, and
    update (or create) the matching AttendanceRecord — the SAME table and
    fields used by the manual att_checkin/att_checkout views, so biometric
    and manual attendance stay perfectly unified.
    """
    local_dt = tz.localtime(punch_time)
    punch_date = local_dt.date()
    punch_clock = local_dt.time()

    record, _ = AttendanceRecord.objects.select_for_update().get_or_create(
        employee=employee,
        date=punch_date,
        defaults={'status': 'present', 'location': 'office'},
    )

    if record.check_in is None:
        # First punch of the day -> check-in
        record.check_in = punch_clock
        record.status = _late_status(punch_clock)
    elif record.check_out is None or punch_clock > record.check_out:
        # Any later punch that day -> keep pushing check-out forward.
        # (Handles multiple punches through the day — device may report
        # break-out/break-in too; we only track first-in / last-out here,
        # which matches the existing AttendanceRecord schema.)
        record.check_out = punch_clock

    _recalculate_hours_and_status(record)
    record.save()

    raw_log.processed = True
    raw_log.processed_at = tz.now()
    raw_log.attendance_record = record
    raw_log.save(update_fields=['processed', 'processed_at', 'attendance_record'])


def _late_status(check_in_clock: dt_time) -> str:
    grace_cutoff = (
        datetime.combine(datetime.today(), OFFICE_START_TIME) + timedelta(minutes=LATE_GRACE_MINUTES)
    ).time()
    return 'late' if check_in_clock > grace_cutoff else 'present'


def _recalculate_hours_and_status(record: AttendanceRecord):
    """Recompute hours_worked, and flag early-logout / keep late status, on every update."""
    if record.check_in and record.check_out:
        base_date = record.date
        cin = datetime.combine(base_date, record.check_in)
        cout = datetime.combine(base_date, record.check_out)
        if cout > cin:
            delta = cout - cin
            record.hours_worked = round(delta.total_seconds() / 3600, 2)

        early_cutoff = (
            datetime.combine(base_date, OFFICE_END_TIME) - timedelta(minutes=EARLY_LOGOUT_GRACE_MINUTES)
        ).time()
        if record.check_out < early_cutoff and record.status != 'late':
            # Keep 'late' if already late; otherwise note early logout in work_summary
            # without inventing a new status value the rest of the app doesn't expect.
            if 'Early logout' not in (record.work_summary or ''):
                note = f"[Biometric] Early logout at {record.check_out.strftime('%H:%M')}"
                record.work_summary = (record.work_summary + ' ' + note).strip() if record.work_summary else note

        ot_cutoff = (
            datetime.combine(base_date, OFFICE_END_TIME) + timedelta(minutes=OVERTIME_AFTER_MINUTES)
        ).time()
        if record.check_out > ot_cutoff:
            ot_minutes = (
                datetime.combine(base_date, record.check_out) - datetime.combine(base_date, ot_cutoff)
            ).total_seconds() / 60
            note = f"[Biometric] Overtime ~{int(ot_minutes)} min"
            if 'Overtime' not in (record.work_summary or ''):
                record.work_summary = (record.work_summary + ' ' + note).strip() if record.work_summary else note
