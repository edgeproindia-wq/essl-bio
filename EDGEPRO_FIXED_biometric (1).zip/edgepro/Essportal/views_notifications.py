from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.shortcuts import redirect, render
from django.views.decorators.http import require_POST

from .models import Notification, NotificationPreference
from .notifications import create_notification


@login_required
def notification_list(request):
    notifications = Notification.objects.filter(user=request.user)[:50]
    return render(request, 'notifications/list.html', {'notifications': notifications})


@login_required
def notification_mark_read(request, notif_id):
    notif = Notification.objects.filter(user=request.user, id=notif_id).first()
    if notif:
        notif.is_read = True
        notif.save(update_fields=['is_read'])
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        unread = Notification.objects.filter(user=request.user, is_read=False).count()
        return JsonResponse({'ok': True, 'unread': unread})
    return redirect('notification_list')


@login_required
@require_POST
def notification_mark_all_read(request):
    Notification.objects.filter(user=request.user, is_read=False).update(is_read=True)
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return JsonResponse({'ok': True, 'unread': 0})
    messages.success(request, 'All notifications marked as read.')
    return redirect('notification_list')


@login_required
def notification_api(request):
    unread = Notification.objects.filter(user=request.user, is_read=False).order_by('-created_at')[:10]
    data = [{
        'id': n.id,
        'title': n.title,
        'message': n.message,
        'category': n.category,
        'link': n.link,
        'created_at': n.created_at.strftime('%d %b %Y %H:%M'),
        'is_read': n.is_read,
    } for n in unread]
    count = Notification.objects.filter(user=request.user, is_read=False).count()
    return JsonResponse({'notifications': data, 'unread_count': count})


@login_required
def notification_preferences(request):
    prefs, _ = NotificationPreference.objects.get_or_create(user=request.user)
    if request.method == 'POST':
        prefs.email_enabled = request.POST.get('email_enabled') == 'on'
        prefs.push_enabled = request.POST.get('push_enabled') == 'on'
        prefs.sms_enabled = request.POST.get('sms_enabled') == 'on'
        prefs.weekly_digest = request.POST.get('weekly_digest') == 'on'
        prefs.push_token = request.POST.get('push_token', prefs.push_token)
        prefs.save()
        messages.success(request, 'Notification preferences saved.')
        return redirect('notification_preferences')
    return render(request, 'notifications/preferences.html', {'prefs': prefs})


@login_required
@require_POST
def register_push_token(request):
    token = request.POST.get('push_token', '').strip()
    if token:
        prefs, _ = NotificationPreference.objects.get_or_create(user=request.user)
        prefs.push_token = token
        prefs.push_enabled = True
        prefs.save()
        create_notification(
            request.user,
            'Push notifications enabled',
            'Your device is registered for push alerts.',
            category='general',
            send_email=False,
            send_push=False,
        )
    return JsonResponse({'ok': True})
