import calendar
import datetime
import os
import random

from django.conf import settings
from django.contrib import messages
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.contrib.auth.models import User
from django.core.mail import send_mail
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.db.models import Q
from django.utils import timezone

from .models import (
    AnnouncementAttachment,
    AttendanceRecord,
    BonusRecord,
    Complaint,
    DailyWorkUpdate,
    EmployeeProfile,
    EmployeeSalary,
    InterviewSchedule,
    JobApplication,
    JobPosting,
    LateLoginRequest,
    LeaveApplication,
    LeaveBalance,
    LeaveDraft,
    PolicyAnnouncement,
    PolicyCategory,
    Project,
    Task,
    TimeEntry,
    WorkflowRequest,
)
from .notifications import create_notification, notify_all_employees, notify_hr_admins, notify_team_leader
from .permissions import (
    can_approve_leave_at_stage,
    get_user_role,
    hr_admin_required,
    is_hr_or_admin,
    is_team_leader,
)
from .views_auth import forgot_password, register_unified


# ── Login / Logout ─────────────────────────────────────────────────────────────
def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, f'Welcome back, {user.get_full_name() or user.username}!')
            return redirect('dashboard')
        else:
            messages.error(request, 'Invalid credentials. Please check your username and password.')
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})


def logout_view(request):
    logout(request)
    return redirect('login')


def register(request):
    return register_unified(request)


# ── Dashboard ──────────────────────────────────────────────────────────────────
@login_required
def dashboard(request):
    recent_announcements = PolicyAnnouncement.objects.filter(status='published').order_by('-created_at')[:5]
    total_announcements = PolicyAnnouncement.objects.filter(status='published').count()
    pending_leaves = LeaveApplication.objects.filter(status='pending').count()
    today = timezone.localtime(timezone.now()).date()
    days_present = AttendanceRecord.objects.filter(employee=request.user, status='present').count()
    try:
        leave_bal = request.user.leave_balance
        leave_balance = (leave_bal.casual_total - leave_bal.casual_used +
                         leave_bal.sick_total - leave_bal.sick_used)
    except Exception:
        # New user with no leave balance record yet — create one with default entitlements
        # instead of showing a fake demo number.
        leave_bal, _ = LeaveBalance.objects.get_or_create(employee=request.user)
        leave_balance = (leave_bal.casual_total - leave_bal.casual_used +
                         leave_bal.sick_total - leave_bal.sick_used)

    casual_available = leave_bal.casual_total - leave_bal.casual_used
    sick_available = leave_bal.sick_total - leave_bal.sick_used
    earned_available = leave_bal.earned_total - leave_bal.earned_used
    recent_leave_apps = LeaveApplication.objects.filter(employee=request.user).order_by('-applied_on')[:3]

    try:
        emp_profile = request.user.profile
    except Exception:
        emp_profile = None

    user_role = get_user_role(request.user)
    role_labels = {'admin': 'Administrator', 'hr': 'HR Manager', 'employee': 'Employee'}
    unread_notifications = request.user.notifications.filter(is_read=False).count() if request.user.is_authenticated else 0

    # Blood groups for dropdown
    blood_groups = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-']
    
    context = {
        'recent_announcements': recent_announcements,
        'total_announcements': total_announcements,
        'pending_leaves': pending_leaves,
        'days_present': days_present,
        'leave_balance': leave_balance,
        'casual_available': casual_available,
        'sick_available': sick_available,
        'earned_available': earned_available,
        'comp_off_balance': leave_bal.comp_off,
        'recent_leave_apps': recent_leave_apps,
        'is_hr_admin': is_hr_or_admin(request.user),
        'is_admin': request.user.is_superuser,
        'user_role': role_labels.get(user_role, 'Employee'),
        'unread_notifications': unread_notifications,
        'user': request.user,
        'emp_profile': emp_profile,
        'blood_groups': blood_groups,
    }
    return render(request, 'dashboard.html', context)


# ── Announcements ──────────────────────────────────────────────────────────────
@login_required
def announcement_list(request):
    cat_slug = request.GET.get('category', '')
    announcements = PolicyAnnouncement.objects.filter(status='published')
    if cat_slug:
        announcements = announcements.filter(category__slug=cat_slug)
    categories = PolicyCategory.objects.all()
    return render(request, 'Announcement.html/announcement.list.html', {
        'announcements': announcements, 'categories': categories, 'active_cat': cat_slug,
    })


@login_required
def announcement_detail(request, slug):
    ann = get_object_or_404(PolicyAnnouncement, slug=slug)
    ann.views_count += 1
    ann.save()
    return render(request, 'Announcement.html/deatils.list.html', {'announcement': ann})


@login_required
def category_announcements(request, slug):
    category = get_object_or_404(PolicyCategory, slug=slug)
    announcements = PolicyAnnouncement.objects.filter(category=category, status='published')
    return render(request, 'Announcement.html/announcement.list.html', {
        'announcements': announcements, 'category': category,
    })


@login_required
@hr_admin_required
def announcement_dashboard(request):
    announcements = PolicyAnnouncement.objects.all()
    return render(request, 'Announcement.html/dashboard.list.html', {'announcements': announcements})


@login_required
@hr_admin_required
def announcement_create(request):
    if request.method == 'POST':
        title = request.POST.get('title', '').strip()
        content = request.POST.get('content', '').strip()
        summary = request.POST.get('summary', '')
        priority = request.POST.get('priority', 'medium')
        audience = request.POST.get('target_audience', 'All Employees')
        pinned = request.POST.get('is_pinned') == 'on'
        action = request.POST.get('action', 'publish')
        slug = title.lower().replace(' ', '-')[:80]
        # ensure unique slug
        base = slug
        counter = 1
        while PolicyAnnouncement.objects.filter(slug=slug).exists():
            slug = f"{base}-{counter}"
            counter += 1
        ann = PolicyAnnouncement.objects.create(
            title=title, slug=slug, content=content, summary=summary,
            priority=priority, target_audience=audience, is_pinned=pinned,
            status='published' if action == 'publish' else 'draft',
            published_at=timezone.now() if action == 'publish' else None,
            created_by=request.user,
        )
        if action == 'publish':
            notify_all_employees(
                f'New Announcement: {title}',
                summary or content[:200],
                category='announcement',
                link=f'/announcements/{ann.slug}/',
            )
        messages.success(request, 'Announcement published successfully!' if action == 'publish' else 'Saved as draft.')
        return redirect('announcement_list')
    categories = PolicyCategory.objects.all()
    return render(request, 'Announcement.html/HR Announcement.html', {'categories': categories})


@login_required
@hr_admin_required
def announcement_edit(request, slug):
    ann = get_object_or_404(PolicyAnnouncement, slug=slug)
    if request.method == 'POST':
        ann.title = request.POST.get('title', ann.title)
        ann.content = request.POST.get('content', ann.content)
        ann.summary = request.POST.get('summary', ann.summary)
        ann.priority = request.POST.get('priority', ann.priority)
        ann.save()
        messages.success(request, 'Announcement updated.')
        return redirect('announcement_detail', slug=ann.slug)
    return render(request, 'Announcement.html/HR Announcement.html', {'announcement': ann})


@login_required
@hr_admin_required
def announcement_delete(request, slug):
    ann = get_object_or_404(PolicyAnnouncement, slug=slug)
    if request.method == 'POST':
        ann.delete()
        return redirect('announcement_list')
    return render(request, 'Announcement.html/confirm.delite.html', {'announcement': ann})


@login_required
def toggle_pin(request, slug):
    if not is_hr_or_admin(request.user):
        return JsonResponse({'error': 'Permission denied'}, status=403)
    ann = get_object_or_404(PolicyAnnouncement, slug=slug)
    ann.is_pinned = not ann.is_pinned
    ann.save()
    return JsonResponse({'pinned': ann.is_pinned})


# ── Attendance ─────────────────────────────────────────────────────────────────
@login_required
def att_checkin(request):
    from django.utils import timezone as tz
    today = tz.localtime(tz.now()).date()
    record, _ = AttendanceRecord.objects.get_or_create(employee=request.user, date=today)

    if request.method == 'POST':
        if record.check_in:
            messages.error(request, "You have already checked in today.")
            return redirect('att_checkin')
        record.check_in = tz.localtime(tz.now()).time()
        record.location = request.POST.get('work_mode', request.POST.get('location', 'office'))
        record.note = request.POST.get('note', '')
        record.status = 'present'
        record.save()
        messages.success(request, f"Check In marked at {record.check_in.strftime('%I:%M %p')}!")
        return redirect('att_checkin')

    already_checked_in = bool(record.check_in)
    return render(request, 'Attendance.html/check.in.html', {
        'record': record,
        'today_record': record,           # alias templates may use
        'already_checked_in': already_checked_in,
        'today': today,
        'now': tz.now(),
        'week_records': AttendanceRecord.objects.filter(employee=request.user).order_by('-date')[:5],
        'employees': [],                  # non-staff employees list (empty unless HR)
    })


@login_required
def att_checkout(request):
    from django.utils import timezone as tz
    from datetime import datetime
    today = tz.localtime(tz.now()).date()
    try:
        record = AttendanceRecord.objects.get(employee=request.user, date=today)
    except AttendanceRecord.DoesNotExist:
        record = None

    if request.method == 'POST' and record:
        record.check_out = tz.localtime(tz.now()).time()
        record.work_summary = request.POST.get('tasks_done', request.POST.get('work_summary', ''))
        if record.check_in and record.check_out:
            cin = datetime.combine(today, record.check_in)
            cout = datetime.combine(today, record.check_out)
            if cout > cin:
                delta = cout - cin
                record.hours_worked = round(delta.total_seconds() / 3600, 2)
        record.save()
        messages.success(request, "Check Out recorded! Have a great evening.")
        return redirect('att_checkout')

    monthly = AttendanceRecord.objects.filter(
        employee=request.user, date__month=today.month, date__year=today.year
    )
    MOODS = [('😀','Great'), ('🙂','Good'), ('😐','Okay'), ('😔','Tired'), ('😤','Stressed')]

    # Human-readable check-in/check-out time difference (e.g. "8h 24m") instead of raw decimal hours
    hours_worked_display = None
    if record and record.hours_worked:
        total_minutes = int(round(float(record.hours_worked) * 60))
        h, m = divmod(total_minutes, 60)
        hours_worked_display = f"{h}h {m}m"

    # Today's status — always known, regardless of check-in/out state
    if not record or not record.check_in:
        today_status = 'not_checked_in'
    elif record.check_in and not record.check_out:
        today_status = 'checked_in'
    else:
        today_status = 'checked_out'

    return render(request, 'Attendance.html/check.out.html', {
        'record': record,
        'today_record': record,           # template uses this name
        'today': today,
        'now': tz.now(),
        'moods': MOODS,
        'present_count': monthly.filter(status='present').count(),
        'absent_count': monthly.filter(status='absent').count(),
        'late_count': monthly.filter(status='late').count(),
        'hours_worked_display': hours_worked_display,
        'today_status': today_status,
    })


@login_required
def att_late(request):
    if request.method == 'POST':
        late_req = LateLoginRequest.objects.create(
            employee=request.user,
            date=request.POST.get('date', timezone.localtime(timezone.now()).date()),
            actual_checkin=request.POST.get('actual_checkin', '10:00'),
            reason=request.POST.get('reason', 'other'),
            details=request.POST.get('details', ''),
        )
        WorkflowRequest.objects.create(
            request_type='late_login',
            employee=request.user,
            description=f'Late login on {late_req.date}: {late_req.get_reason_display()}',
            from_date=late_req.date,
        )
        notify_team_leader(
            request.user,
            'Late Login Request Submitted',
            f'{request.user.get_full_name()} submitted a late login request for {late_req.date}.',
            category='attendance',
            link='/attendance/late/',
        )
        messages.success(request, "Late login request submitted for approval!")
        return redirect('att_late')
    if is_hr_or_admin(request.user):
        history = LateLoginRequest.objects.all().order_by('-created_at')[:20]
    else:
        history = LateLoginRequest.objects.filter(employee=request.user).order_by('-date')[:10]
    return render(request, 'Attendance.html/late login.html', {
        'history': history,
        'is_hr_admin': is_hr_or_admin(request.user),
    })


@login_required
@hr_admin_required
def att_approve_late(request):
    if request.method == 'POST':
        req_id = request.POST.get('req_id')
        action = request.POST.get('action')
        try:
            late_req = LateLoginRequest.objects.get(id=req_id)
            late_req.status = 'approved' if action == 'approve' else 'rejected'
            late_req.manager = request.user
            late_req.save()
            WorkflowRequest.objects.filter(
                employee=late_req.employee,
                request_type='late_login',
                from_date=late_req.date,
                status='pending',
            ).update(status=late_req.status, approver=request.user, decided_at=timezone.now())
            create_notification(
                late_req.employee,
                f'Late Login {"Approved" if action == "approve" else "Rejected"}',
                f'Your late login request for {late_req.date} was {late_req.status}.',
                category='attendance',
                link='/attendance/late/',
            )
            messages.success(request, f'Late login request {late_req.status}.')
        except LateLoginRequest.DoesNotExist:
            pass
        return redirect('att_late')
    return redirect('att_late')


@login_required
def att_monthly(request):
    import calendar as _calendar
    from datetime import date as _date

    today = timezone.localtime(timezone.now()).date()
    MIN_YEAR = 2025

    month = int(request.GET.get('month', today.month))
    year = int(request.GET.get('year', today.year))

    # Clamp requested month/year into the valid range: Jan 2025 .. current month
    if year < MIN_YEAR:
        year, month = MIN_YEAR, 1
    if year > today.year or (year == today.year and month > today.month):
        year, month = today.year, today.month
    if month < 1:
        month = 1
    if month > 12:
        month = 12

    hr_admin = is_hr_or_admin(request.user)
    employees = User.objects.filter(is_active=True).order_by('first_name') if hr_admin else User.objects.filter(id=request.user.id)

    days_in_month = _calendar.monthrange(year, month)[1]
    first_day_date = _date(year, month, 1)
    start_padding = (first_day_date.weekday() + 1) % 7  # Sunday-first grid

    my_records = {r.date: r for r in AttendanceRecord.objects.filter(employee=request.user, date__month=month, date__year=year)}

    day_names = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa']
    calendar_days = [{'empty': True} for _ in range(start_padding)]
    for day_num in range(1, days_in_month + 1):
        d = _date(year, month, day_num)
        is_future = d > today
        is_weekend = d.weekday() >= 5
        record = my_records.get(d)
        if is_future:
            status, label = 'future', 'Upcoming'
        elif record:
            status, label = record.status, record.get_status_display()
        elif is_weekend:
            status, label = 'weekend', 'Weekend'
        else:
            status, label = 'absent', 'Absent'
        calendar_days.append({
            'empty': False, 'day': day_num, 'date': d, 'status': status,
            'is_today': d == today, 'is_future': is_future, 'label': label,
        })

    all_month_records = AttendanceRecord.objects.filter(date__month=month, date__year=year, employee__in=employees)
    working_days = sum(1 for n in range(1, days_in_month + 1) if _date(year, month, n).weekday() < 5)
    total_present = all_month_records.filter(status='present').count()
    total_late = all_month_records.filter(status='late').count()
    total_absent = all_month_records.filter(status='absent').count()
    total_employee_days = employees.count() * working_days
    avg_attendance = round((total_present / total_employee_days) * 100, 1) if total_employee_days else 0

    stats = {
        'working_days': working_days,
        'avg_attendance': avg_attendance,
        'total_present': total_present,
        'total_late': total_late,
        'total_absent': total_absent,
        'holidays': 0,
        'total_days_in_month': days_in_month,
    }

    avatar_colors = ['#7c3aed', '#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#6366f1']
    employee_summary = []
    denom = working_days or 1
    for idx, emp in enumerate(employees):
        emp_records = all_month_records.filter(employee=emp)
        present = emp_records.filter(status='present').count()
        absent = emp_records.filter(status='absent').count()
        late = emp_records.filter(status='late').count()
        halfday = emp_records.filter(status='halfday').count()
        try:
            department = emp.profile.department
        except Exception:
            department = ''
        employee_summary.append({
            'employee': emp,
            'department': department,
            'present': present, 'absent': absent, 'late': late, 'halfday': halfday,
            'attendance_pct': round((present / denom) * 100, 1),
            'present_pct': round((present / denom) * 100, 1),
            'late_pct': round((late / denom) * 100, 1),
            'absent_pct': round((absent / denom) * 100, 1),
            'avatar_color': avatar_colors[idx % len(avatar_colors)],
            'total_days_in_month': days_in_month,
        })

    prev_month, prev_year = (month - 1, year) if month > 1 else (12, year - 1)
    next_month, next_year = (month + 1, year) if month < 12 else (1, year + 1)
    can_go_prev = prev_year >= MIN_YEAR
    can_go_next = not (next_year > today.year or (next_year == today.year and next_month > today.month))

    return render(request, 'Attendance.html/monthly attendance.html', {
        'month': month, 'year': year, 'month_name': _calendar.month_name[month],
        'day_names': day_names, 'calendar_days': calendar_days, 'stats': stats,
        'employee_summary': employee_summary,
        'prev_month': prev_month, 'prev_year': prev_year, 'can_go_prev': can_go_prev,
        'next_month': next_month, 'next_year': next_year, 'can_go_next': can_go_next,
        'year_options': list(range(MIN_YEAR, today.year + 1)),
        'month_options': [(i, _calendar.month_name[i]) for i in range(1, 13)],
        'is_hr_admin': hr_admin,
        'current_month': today.month, 'current_year': today.year,
    })


# ── Leave Management ───────────────────────────────────────────────────────────
def _get_leave_balance(user):
    bal, _ = LeaveBalance.objects.get_or_create(employee=user)
    return bal


def _is_ajax(request):
    return (
        request.headers.get('x-requested-with') == 'XMLHttpRequest'
        or 'application/json' in request.headers.get('accept', '')
    )


VALID_LEAVE_TYPES = {'casual', 'sick', 'earned', 'emergency', 'maternity', 'comp_off', 'cash'}
VALID_LEAVE_SESSIONS = {'full', 'first', 'second'}


def _num_days_from_dates(from_date_raw, to_date_raw):
    """Inclusive day count between two ISO date strings. Falls back to 1 if unparseable."""
    from datetime import date
    try:
        f = date.fromisoformat((from_date_raw or '').strip())
        t = date.fromisoformat((to_date_raw or '').strip())
        return max(1, (t - f).days + 1)
    except (TypeError, ValueError):
        return 1


def _validate_leave_payload(data):
    """Validate raw POST data for a leave application. Returns (cleaned, errors)."""
    from datetime import date

    errors = {}
    cleaned = {}

    department = (data.get('department') or '').strip()
    if not department:
        errors['department'] = 'Department is required.'
    elif len(department) > 100:
        errors['department'] = 'Department name is too long (max 100 characters).'
    cleaned['department'] = department

    leave_type = (data.get('leave_type') or '').strip()
    if leave_type not in VALID_LEAVE_TYPES:
        errors['leave_type'] = 'Please select a valid leave type.'
    cleaned['leave_type'] = leave_type

    session = (data.get('session') or 'full').strip()
    if session not in VALID_LEAVE_SESSIONS:
        errors['session'] = 'Invalid session selected.'
    cleaned['session'] = session

    from_date_raw = (data.get('from_date') or '').strip()
    to_date_raw = (data.get('to_date') or '').strip()
    from_date = to_date = None
    if not from_date_raw:
        errors['from_date'] = 'From date is required.'
    if not to_date_raw:
        errors['to_date'] = 'To date is required.'
    if from_date_raw and to_date_raw:
        try:
            from_date = date.fromisoformat(from_date_raw)
            to_date = date.fromisoformat(to_date_raw)
            if to_date < from_date:
                errors['to_date'] = 'To date cannot be before the from date.'
        except ValueError:
            errors['from_date'] = 'Please provide valid dates.'
    cleaned['from_date'] = from_date_raw
    cleaned['to_date'] = to_date_raw

    # Number of days is always derived from the dates on the server — never trusted
    # from the client's hidden field, which can be stale (JS didn't fire) or tampered with.
    # NOTE: casual_used/sick_used on LeaveBalance are IntegerField, so half-day (first/second
    # session) leaves cannot deduct a fractional day yet. That needs a migration
    # (IntegerField -> DecimalField) before half-day accounting can be made accurate;
    # for now a half-day session still counts as 1 full day here, same as before.
    if from_date and to_date:
        num_days = (to_date - from_date).days + 1  # inclusive of both ends
        if session in ('first', 'second') and from_date != to_date:
            errors['session'] = 'Half-day sessions can only be selected for a single-day leave.'
    else:
        num_days = 1  # dates missing/invalid; from_date/to_date errors above already cover this
    cleaned['num_days'] = num_days

    reason = (data.get('reason') or '').strip()
    if not reason:
        errors['reason'] = 'Please provide a reason for your leave.'
    cleaned['reason'] = reason

    cleaned['handover_to'] = (data.get('handover_to') or '').strip()
    cleaned['contact'] = (data.get('contact') or '').strip()

    return cleaned, errors


@login_required
def leave_apply(request):
    if request.method == 'POST':
        cleaned, errors = _validate_leave_payload(request.POST)

        bal = _get_leave_balance(request.user)
        leave_type = cleaned['leave_type']
        num_days = cleaned['num_days']

        if not errors:
            if leave_type == 'casual':
                available = bal.casual_total - bal.casual_used
                if num_days > available:
                    errors['num_days'] = f"Insufficient casual leave balance. Available: {available} days."
            elif leave_type == 'sick':
                available = bal.sick_total - bal.sick_used
                if num_days > available:
                    errors['num_days'] = f"Insufficient sick leave balance. Available: {available} days."
            elif leave_type == 'cash':
                available = bal.cash_total - bal.cash_used
                if num_days > available:
                    errors['num_days'] = f"Insufficient cash leave balance. Available: {available} days."

        if errors:
            if _is_ajax(request):
                return JsonResponse({'success': False, 'errors': errors}, status=400)
            for msg in errors.values():
                messages.error(request, msg)
            recent = LeaveApplication.objects.filter(employee=request.user).order_by('-applied_on')[:3]
            return render(request, 'Leave Management.html/apply leave.html', {
                'balance': bal, 'recent': recent, 'form_errors': errors,
                'casual_available': bal.casual_total - bal.casual_used,
                'sick_available': bal.sick_total - bal.sick_used,
                'earned_available': bal.earned_total - bal.earned_used,
            })

        leave_app = LeaveApplication.objects.create(
            employee=request.user,
            department=cleaned['department'],
            leave_type=leave_type,
            from_date=cleaned['from_date'],
            to_date=cleaned['to_date'],
            session=cleaned['session'],
            num_days=num_days,
            reason=cleaned['reason'],
            handover_to=cleaned['handover_to'],
            contact_during_leave=cleaned['contact'],
            supporting_doc=request.FILES.get('supporting_doc'),
            approval_stage='tl',
        )
        WorkflowRequest.objects.create(
            request_type='leave',
            employee=request.user,
            description=f'{leave_type.title()} leave: {leave_app.from_date} to {leave_app.to_date}',
            from_date=leave_app.from_date,
            to_date=leave_app.to_date,
        )

        try:
            notify_team_leader(
                request.user,
                'New Leave Request',
                f'{request.user.get_full_name()} applied for {leave_app.get_leave_type_display()} '
                f'({leave_app.from_date} to {leave_app.to_date}). Please review.',
                category='leave',
                link='/leave/tl-approval/',
            )
            create_notification(
                request.user,
                'Leave Request Submitted',
                f'Your {leave_app.get_leave_type_display()} request ({leave_app.application_no}) was sent to your Team Leader.',
                category='leave',
                link='/leave/history/',
                send_email=False,
            )
        except Exception:
            pass

        # Deduct balance immediately (pending approval flow can reverse this)
        if leave_type == 'casual':
            bal.casual_used += int(num_days)
            bal.save()
        elif leave_type == 'sick':
            bal.sick_used += int(num_days)
            bal.save()
        elif leave_type == 'cash':
            bal.cash_used += int(num_days)
            bal.save()

        type_labels = {'casual': 'Casual', 'sick': 'Sick', 'cash': 'Cash'}
        label = type_labels.get(leave_type, leave_type.title())
        success_message = f"{label} leave application submitted successfully!"

        if _is_ajax(request):
            return JsonResponse({
                'success': True,
                'message': success_message,
                'application_no': leave_app.application_no,
                'redirect_url': '/leave/history/',
            })

        messages.success(request, success_message)
        return redirect('leave_history')

    bal = _get_leave_balance(request.user)
    recent = LeaveApplication.objects.filter(employee=request.user).order_by('-applied_on')[:3]
    return render(request, 'Leave Management.html/apply leave.html', {
        'balance': bal,
        'recent': recent,
        'casual_available': bal.casual_total - bal.casual_used,
        'sick_available': bal.sick_total - bal.sick_used,
        'earned_available': bal.earned_total - bal.earned_used,
    })


@login_required
def leave_casual(request):
    if request.method == 'POST':
        num_days = _num_days_from_dates(request.POST.get('from_date'), request.POST.get('to_date'))
        bal = _get_leave_balance(request.user)
        available = bal.casual_total - bal.casual_used
        if num_days > available:
            messages.error(request, f"Insufficient casual leave balance. Available: {available} days.")
        else:
            LeaveApplication.objects.create(
                employee=request.user,
                leave_type='casual',
                from_date=request.POST.get('from_date'),
                to_date=request.POST.get('to_date'),
                session=request.POST.get('session', 'full'),
                num_days=num_days,
                reason=request.POST.get('reason', ''),
                contact_during_leave=request.POST.get('contact', ''),
            )
            bal.casual_used += int(num_days)
            bal.save()
            messages.success(request, "Casual leave application submitted successfully!")
            return redirect('leave_history')
    bal = _get_leave_balance(request.user)
    history = LeaveApplication.objects.filter(employee=request.user, leave_type='casual').order_by('-applied_on')[:10]
    available = bal.casual_total - bal.casual_used
    return render(request, 'Leave Management.html/casual.html', {'balance': bal, 'history': history, 'available': available})


@login_required
def leave_sick(request):
    if request.method == 'POST':
        num_days = _num_days_from_dates(request.POST.get('from_date'), request.POST.get('to_date'))
        bal = _get_leave_balance(request.user)
        available = bal.sick_total - bal.sick_used
        if num_days > available:
            messages.error(request, f"Insufficient sick leave balance. Available: {available} days.")
        else:
            LeaveApplication.objects.create(
                employee=request.user,
                leave_type='sick',
                from_date=request.POST.get('from_date'),
                to_date=request.POST.get('to_date'),
                session=request.POST.get('session', 'full'),
                num_days=num_days,
                reason=request.POST.get('reason', ''),
                contact_during_leave=request.POST.get('contact', ''),
            )
            bal.sick_used += int(num_days)
            bal.save()
            messages.success(request, "Sick leave application submitted successfully!")
            return redirect('leave_history')
    bal = _get_leave_balance(request.user)
    history = LeaveApplication.objects.filter(employee=request.user, leave_type='sick').order_by('-applied_on')[:10]
    available = bal.sick_total - bal.sick_used
    return render(request, 'Leave Management.html/sick.html', {'balance': bal, 'history': history, 'available': available})


@login_required
def leave_draft_save(request):
    """Save the current Apply Leave form as a draft via AJAX."""
    if request.method != 'POST':
        return JsonResponse({'success': False, 'errors': {'general': 'Invalid request method.'}}, status=405)

    data = request.POST
    num_days_raw = data.get('num_days')
    try:
        num_days = float(num_days_raw) if num_days_raw else None
    except (TypeError, ValueError):
        num_days = None

    draft = LeaveDraft.objects.create(
        employee=request.user,
        department=(data.get('department') or '').strip(),
        leave_type=(data.get('leave_type') or '').strip(),
        from_date=data.get('from_date') or None,
        to_date=data.get('to_date') or None,
        session=(data.get('session') or 'full').strip(),
        num_days=num_days,
        reason=(data.get('reason') or '').strip(),
        handover_to=(data.get('handover_to') or '').strip(),
        contact_during_leave=(data.get('contact') or '').strip(),
    )
    return JsonResponse({
        'success': True,
        'message': 'Draft saved!',
        'draft_id': draft.id,
        'saved_at': draft.updated_at.strftime('%d %b %Y, %I:%M %p'),
    })


@login_required
def leave_draft_list(request):
    drafts = LeaveDraft.objects.filter(employee=request.user)
    return JsonResponse({
        'success': True,
        'drafts': [
            {
                'id': d.id,
                'department': d.department,
                'leave_type': d.leave_type,
                'from_date': d.from_date.isoformat() if d.from_date else '',
                'to_date': d.to_date.isoformat() if d.to_date else '',
                'session': d.session,
                'num_days': float(d.num_days) if d.num_days else '',
                'reason': d.reason,
                'handover_to': d.handover_to,
                'contact': d.contact_during_leave,
                'updated_at': d.updated_at.strftime('%d %b %Y, %I:%M %p'),
            }
            for d in drafts
        ],
    })


@login_required
def leave_draft_delete(request, draft_id):
    if request.method != 'POST':
        return JsonResponse({'success': False}, status=405)
    LeaveDraft.objects.filter(id=draft_id, employee=request.user).delete()
    return JsonResponse({'success': True})


@login_required
def leave_history(request):
    leave_type = request.GET.get('type', '')
    status = request.GET.get('status', '')
    emp_id = request.GET.get('employee_id', '').strip()

    if emp_id and is_hr_or_admin(request.user):
        # HR/Admin tracking: search any employee's leave records by Employee ID
        try:
            target_profile = EmployeeProfile.objects.get(employee_id__iexact=emp_id)
            all_apps = LeaveApplication.objects.filter(employee=target_profile.user).order_by('-applied_on')
        except EmployeeProfile.DoesNotExist:
            all_apps = LeaveApplication.objects.none()
    else:
        all_apps = LeaveApplication.objects.filter(employee=request.user).order_by('-applied_on')

    apps = all_apps
    if leave_type:
        apps = apps.filter(leave_type=leave_type)
    if status:
        # Filter by leave application status safely
        valid_statuses = ['pending', 'approved', 'rejected', 'cancelled']
        if status and status in valid_statuses:
            apps = apps.filter(status=status)

    if _is_ajax(request):
        def serialize(a):
            return {
                'id': a.id,
                'application_no': a.application_no,
                'employee': a.employee.get_full_name() or a.employee.username,
                'department': a.department,
                'leave_type': a.leave_type,
                'leave_type_display': a.get_leave_type_display(),
                'from_date': a.from_date.strftime('%d %b %Y'),
                'to_date': a.to_date.strftime('%d %b %Y'),
                'session': a.get_session_display(),
                'num_days': float(a.num_days),
                'reason': a.reason,
                'status': a.status,
                'status_display': a.get_status_display(),
                'applied_on': a.applied_on.strftime('%d %b %Y, %I:%M %p'),
            }
        return JsonResponse({
            'success': True,
            'applications': [serialize(a) for a in apps],
            'filters': {'type': leave_type, 'status': status, 'employee_id': emp_id},
            'searched_employee_not_found': bool(emp_id) and is_hr_or_admin(request.user) and not all_apps.exists() and not EmployeeProfile.objects.filter(employee_id__iexact=emp_id).exists(),
        })

    return render(request, 'Leave Management.html/leave history.html', {
        'applications': apps,
        'approved_count': all_apps.filter(status='approved').count(),
        'pending_count': all_apps.filter(status='pending').count(),
        'rejected_count': all_apps.filter(status='rejected').count(),
        'is_hr_admin': is_hr_or_admin(request.user),
        'searched_employee_id': emp_id,
    })


@login_required
def leave_summary(request):
    bal = _get_leave_balance(request.user)
    today = timezone.localtime(timezone.now()).date()
    year = today.year

    my_apps = LeaveApplication.objects.filter(employee=request.user)
    approved_this_month = my_apps.filter(
        status='approved', actioned_on__year=year, actioned_on__month=today.month
    ).count()
    pending_count = my_apps.filter(status='pending').count()
    recent_requests = my_apps.order_by('-applied_on')[:4]

    casual_available = bal.casual_total - bal.casual_used
    sick_available = bal.sick_total - bal.sick_used
    earned_available = bal.earned_total - bal.earned_used
    total_balance = casual_available + sick_available + earned_available
    total_entitlement = bal.casual_total + bal.sick_total + bal.earned_total
    total_used = bal.casual_used + bal.sick_used + bal.earned_used

    def pct(used, total):
        return round((used / total) * 100, 0) if total else 0

    casual_pct = pct(bal.casual_used, bal.casual_total)
    sick_pct = pct(bal.sick_used, bal.sick_total)
    earned_pct = pct(bal.earned_used, bal.earned_total)

    # Colleagues currently on approved leave today
    team_on_leave = LeaveApplication.objects.filter(
        status='approved', from_date__lte=today, to_date__gte=today,
    ).exclude(employee=request.user).select_related('employee')[:5]

    monthly = {}
    for app in my_apps.filter(status='approved'):
        m = app.from_date.strftime('%B')
        monthly[m] = monthly.get(m, 0) + float(app.num_days)

    return render(request, 'Leave Management.html/Leavemanagement dashboard.html', {
        'balance': bal,
        'monthly': monthly,
        'today': today,
        'year': year,
        'casual_available': casual_available,
        'sick_available': sick_available,
        'earned_available': earned_available,
        'casual_pct': casual_pct,
        'sick_pct': sick_pct,
        'earned_pct': earned_pct,
        'total_balance': total_balance,
        'total_entitlement': total_entitlement,
        'total_used': total_used,
        'approved_this_month': approved_this_month,
        'pending_count': pending_count,
        'recent_requests': recent_requests,
        'team_on_leave': team_on_leave,
    })


def _get_team_queryset(user):
    """Who this user should see in team-wide summary views."""
    if is_hr_or_admin(user):
        return User.objects.filter(is_active=True).select_related('profile').order_by('first_name', 'username')
    if is_team_leader(user):
        team = User.objects.filter(is_active=True, profile__reporting_manager=user).select_related('profile')
        return (team | User.objects.filter(pk=user.pk)).distinct().order_by('first_name', 'username')
    manager = getattr(getattr(user, 'profile', None), 'reporting_manager', None)
    if manager:
        team = User.objects.filter(is_active=True, profile__reporting_manager=manager).select_related('profile')
        return (team | User.objects.filter(pk=user.pk)).distinct().order_by('first_name', 'username')
    return User.objects.filter(pk=user.pk)


@login_required
def leave_summary_daily(request):
    date_str = request.GET.get('date')
    try:
        day = datetime.datetime.strptime(date_str, '%Y-%m-%d').date() if date_str else timezone.localtime(timezone.now()).date()
    except ValueError:
        day = timezone.localtime(timezone.now()).date()

    team = list(_get_team_queryset(request.user))
    team_ids = [u.id for u in team]

    attendance_by_emp = {a.employee_id: a for a in AttendanceRecord.objects.filter(employee_id__in=team_ids, date=day)}
    leave_by_emp = {
        l.employee_id: l for l in LeaveApplication.objects.filter(
            employee_id__in=team_ids, status='approved', from_date__lte=day, to_date__gte=day,
        )
    }

    members = []
    present_count = leave_count = wfh_count = absent_count = 0
    for u in team:
        att = attendance_by_emp.get(u.id)
        leave = leave_by_emp.get(u.id)
        if leave:
            status, badge_label = 'leave', leave.get_leave_type_display()
            leave_count += 1
        elif att and att.location == 'wfh':
            status, badge_label = 'wfh', 'WFH'
            wfh_count += 1
        elif att and att.status in ('present', 'late'):
            status, badge_label = 'present', None
            present_count += 1
        elif att and att.status == 'absent':
            status, badge_label = 'absent', 'Absent'
            absent_count += 1
        else:
            status, badge_label = 'absent', 'No record'
            absent_count += 1
        members.append({
            'user': u,
            'designation': getattr(getattr(u, 'profile', None), 'designation', '') or '',
            'status': status,
            'badge_label': badge_label,
            'check_in': att.check_in if att else None,
        })

    activity = list(
        LeaveApplication.objects.filter(employee_id__in=team_ids)
        .filter(Q(applied_on__date=day) | Q(actioned_on__date=day))
        .select_related('employee', 'approver')
        .order_by('-applied_on')[:8]
    )
    upcoming = list(
        LeaveApplication.objects.filter(
            employee_id__in=team_ids, status='approved',
            from_date__gt=day, from_date__lte=day + datetime.timedelta(days=7),
        ).select_related('employee').order_by('from_date')[:8]
    )

    return render(request, 'Leave Management.html/summary.html/daily.html', {
        'day': day,
        'prev_day': day - datetime.timedelta(days=1),
        'next_day': day + datetime.timedelta(days=1),
        'today': timezone.localtime(timezone.now()).date(),
        'members': members,
        'present_count': present_count,
        'leave_count': leave_count,
        'wfh_count': wfh_count,
        'absent_count': absent_count,
        'activity': activity,
        'upcoming': upcoming,
    })


@login_required
def leave_summary_weekly(request):
    date_str = request.GET.get('date')
    try:
        anchor = datetime.datetime.strptime(date_str, '%Y-%m-%d').date() if date_str else timezone.localtime(timezone.now()).date()
    except ValueError:
        anchor = timezone.localtime(timezone.now()).date()
    week_start = anchor - datetime.timedelta(days=anchor.weekday())  # Monday
    weekdays = [week_start + datetime.timedelta(days=i) for i in range(5)]

    team = list(_get_team_queryset(request.user))
    team_ids = [u.id for u in team]

    attendance = AttendanceRecord.objects.filter(employee_id__in=team_ids, date__range=(weekdays[0], weekdays[-1]))
    att_map = {}
    for a in attendance:
        att_map.setdefault(a.employee_id, {})[a.date] = a

    leaves = LeaveApplication.objects.filter(
        employee_id__in=team_ids, status='approved',
        from_date__lte=weekdays[-1], to_date__gte=weekdays[0],
    )
    leave_map = {}
    for l in leaves:
        for d in weekdays:
            if l.from_date <= d <= l.to_date:
                leave_map.setdefault(l.employee_id, {})[d] = l

    rows = []
    present_days = leave_days = wfh_days = 0
    for u in team:
        cells = []
        for d in weekdays:
            att = att_map.get(u.id, {}).get(d)
            leave = leave_map.get(u.id, {}).get(d)
            if leave:
                cells.append({'type': 'leave', 'label': leave.get_leave_type_display()[:2].upper()})
                leave_days += 1
            elif att and att.location == 'wfh':
                cells.append({'type': 'wfh', 'label': 'WFH'})
                wfh_days += 1
            elif att and att.status in ('present', 'late'):
                cells.append({'type': 'present', 'label': att.check_in.strftime('%H:%M') if att.check_in else '✓'})
                present_days += 1
            else:
                cells.append({'type': 'off', 'label': '—'})
        rows.append({'user': u, 'cells': cells})

    possible_days = len(team) * 5
    attendance_pct = round((present_days / possible_days) * 100) if possible_days else 0

    # Leave trend: team-wide approved leave days per week, last 6 weeks including this one
    trend = []
    for i in range(5, -1, -1):
        w_start = week_start - datetime.timedelta(weeks=i)
        w_end = w_start + datetime.timedelta(days=4)
        days_in_week = sum(
            float(l.num_days) for l in LeaveApplication.objects.filter(
                employee_id__in=team_ids, status='approved', from_date__lte=w_end, to_date__gte=w_start,
            )
        )
        trend.append({'label': f"W{w_start.isocalendar()[1]}", 'value': days_in_week, 'current': i == 0})
    max_trend = max((t['value'] for t in trend), default=0) or 1

    year_start = datetime.date(week_start.year, 1, 1)
    member_usage = []
    for u in team:
        used = LeaveApplication.objects.filter(
            employee=u, status='approved', from_date__gte=year_start, from_date__lte=weekdays[-1],
        )
        total_days = sum(float(a.num_days) for a in used)
        member_usage.append({'user': u, 'days': total_days})
    max_usage = max((m['days'] for m in member_usage), default=0) or 1

    return render(request, 'Leave Management.html/summary.html/week.html', {
        'week_start': week_start,
        'week_end': weekdays[-1],
        'week_number': week_start.isocalendar()[1],
        'prev_week': (week_start - datetime.timedelta(days=7)).isoformat(),
        'next_week': (week_start + datetime.timedelta(days=7)).isoformat(),
        'weekdays': weekdays,
        'rows': rows,
        'present_days': present_days,
        'leave_days': leave_days,
        'wfh_days': wfh_days,
        'possible_days': possible_days,
        'attendance_pct': attendance_pct,
        'trend': trend,
        'max_trend': max_trend,
        'member_usage': member_usage,
        'max_usage': max_usage,
    })


@login_required
def leave_summary_monthly(request):
    today = timezone.localtime(timezone.now()).date()
    try:
        year = int(request.GET.get('year', today.year))
        month = int(request.GET.get('month', today.month))
    except (TypeError, ValueError):
        year, month = today.year, today.month
    if month < 1:
        month, year = 12, year - 1
    elif month > 12:
        month, year = 1, year + 1

    team = list(_get_team_queryset(request.user))
    team_ids = [u.id for u in team]

    first_day = datetime.date(year, month, 1)
    days_in_month = calendar.monthrange(year, month)[1]
    last_day = datetime.date(year, month, days_in_month)

    apps = LeaveApplication.objects.filter(
        employee_id__in=team_ids, from_date__lte=last_day, to_date__gte=first_day,
    ).select_related('employee')

    events_by_day = {}
    day_counts = {}
    for a in apps:
        span_start = max(a.from_date, first_day)
        span_end = min(a.to_date, last_day)
        d = span_start
        while d <= span_end:
            cls = 'ev-pending' if a.status == 'pending' else ('ev-sick' if a.leave_type == 'sick' else 'ev-casual')
            label = f"{a.employee.first_name or a.employee.username} – {a.get_leave_type_display()}"
            events_by_day.setdefault(d.day, []).append({'text': label, 'cls': cls})
            if a.status == 'approved':
                day_counts[d.day] = day_counts.get(d.day, 0) + 1
            d += datetime.timedelta(days=1)

    working_days = sum(1 for d in range(1, days_in_month + 1) if datetime.date(year, month, d).weekday() < 5)
    leaves_taken = sum(1 for a in apps if a.status == 'approved')
    pending_count = sum(1 for a in apps if a.status == 'pending')
    approved_count = leaves_taken
    rejected_count = sum(1 for a in apps if a.status == 'rejected')
    total_apps = apps.count()

    present_qs = AttendanceRecord.objects.filter(
        employee=request.user, date__gte=first_day, date__lte=min(last_day, today), status__in=['present', 'late'],
    )
    my_present_days = present_qs.count()

    possible_days = working_days * len(team) if team else working_days
    team_present = AttendanceRecord.objects.filter(
        employee_id__in=team_ids, date__gte=first_day, date__lte=min(last_day, today), status__in=['present', 'late'],
    ).count()
    attendance_pct = round((team_present / possible_days) * 100) if possible_days else 0

    type_counts = {}
    for a in apps:
        type_counts[a.get_leave_type_display()] = type_counts.get(a.get_leave_type_display(), 0) + 1
    most_common_type = max(type_counts, key=type_counts.get) if type_counts else '—'

    peak_day = max(day_counts, key=day_counts.get) if day_counts else None
    peak_day_label = f"{calendar.month_abbr[month]} {peak_day}" if peak_day else '—'

    avg_leave = round(approved_count / len(team), 2) if team else 0

    # Month-by-month trend for the year so far (Jan..current month, capped at 6 columns ending this month)
    month_trend = []
    for offset in range(5, -1, -1):
        m = month - offset
        y = year
        while m < 1:
            m += 12
            y -= 1
        m_start = datetime.date(y, m, 1)
        m_end = datetime.date(y, m, calendar.monthrange(y, m)[1])
        cnt = LeaveApplication.objects.filter(
            employee_id__in=team_ids, status='approved', from_date__lte=m_end, to_date__gte=m_start,
        ).count()
        month_trend.append({'label': calendar.month_abbr[m], 'value': cnt, 'current': offset == 0})
    max_month_trend = max((m['value'] for m in month_trend), default=0) or 1

    raw_weeks = calendar.Calendar(firstweekday=6).monthdayscalendar(year, month)  # Sunday-first
    cal_weeks = []
    for week in raw_weeks:
        week_cells = []
        for dow, d in enumerate(week):
            if d == 0:
                week_cells.append(None)
            else:
                week_cells.append({
                    'day': d,
                    'events': events_by_day.get(d, []),
                    'is_weekend': dow == 0 or dow == 6,
                    'is_today': (year == today.year and month == today.month and d == today.day),
                })
        cal_weeks.append(week_cells)

    return render(request, 'Leave Management.html/summary.html/monthly.html', {
        'year': year,
        'month': month,
        'month_name': calendar.month_name[month],
        'prev_month': (month - 1) if month > 1 else 12,
        'prev_year': year if month > 1 else year - 1,
        'next_month': (month + 1) if month < 12 else 1,
        'next_year': year if month < 12 else year + 1,
        'today': today,
        'cal_weeks': cal_weeks,
        'events_by_day': events_by_day,
        'working_days': working_days,
        'leaves_taken': leaves_taken,
        'my_present_days': my_present_days,
        'attendance_pct': attendance_pct,
        'pending_count': pending_count,
        'total_apps': total_apps,
        'approved_count': approved_count,
        'rejected_count': rejected_count,
        'avg_leave': avg_leave,
        'most_common_type': most_common_type,
        'peak_day_label': peak_day_label,
        'month_trend': month_trend,
        'max_month_trend': max_month_trend,
    })


def _restore_leave_balance(app):
    bal = _get_leave_balance(app.employee)
    days = int(float(app.num_days))
    if app.leave_type == 'casual':
        bal.casual_used = max(0, bal.casual_used - days)
    elif app.leave_type == 'sick':
        bal.sick_used = max(0, bal.sick_used - days)
    elif app.leave_type == 'cash':
        bal.cash_used = max(0, bal.cash_used - days)
    bal.save()


@login_required
def leave_tlapproval(request):
    if request.method == 'POST':
        app_id = request.POST.get('app_id')
        action = request.POST.get('action')
        try:
            app = LeaveApplication.objects.get(id=app_id)
            if not can_approve_leave_at_stage(request.user, app):
                messages.error(request, 'You are not authorized to action this request.')
                return redirect('leave_tlapproval')

            if action == 'approve':
                if app.approval_stage == 'tl':
                    app.tl_approver = request.user
                    app.tl_approved_at = timezone.now()
                    app.approval_stage = 'hr'
                    app.save()
                    notify_hr_admins(
                        'Leave Pending HR Approval',
                        f'{app.employee.get_full_name()} leave ({app.application_no}) approved by TL. HR review required.',
                        category='leave',
                        link='/leave/tl-approval/',
                    )
                    create_notification(
                        app.employee,
                        'Leave Approved by Team Leader',
                        f'Your {app.get_leave_type_display()} request was approved by your TL and forwarded to HR.',
                        category='leave',
                        link='/leave/history/',
                    )
                    messages.success(request, f'Forwarded to HR for {app.employee.get_full_name()}.')
                elif app.approval_stage == 'hr':
                    app.status = 'approved'
                    app.approver = request.user
                    app.approval_stage = 'done'
                    app.actioned_on = timezone.now()
                    app.save()
                    WorkflowRequest.objects.filter(
                        employee=app.employee,
                        request_type='leave',
                        from_date=app.from_date,
                        status='pending',
                    ).update(status='approved', approver=request.user, decided_at=timezone.now())
                    create_notification(
                        app.employee,
                        'Leave Approved',
                        f'Your {app.get_leave_type_display()} application ({app.application_no}) has been approved by HR.',
                        category='leave',
                        link='/leave/history/',
                    )
                    messages.success(request, f'Leave approved for {app.employee.get_full_name()}!')
            elif action == 'reject':
                app.status = 'rejected'
                app.approval_stage = 'done'
                app.rejection_reason = request.POST.get('rejection_reason', '')
                app.approver = request.user
                app.actioned_on = timezone.now()
                app.save()
                _restore_leave_balance(app)
                WorkflowRequest.objects.filter(
                    employee=app.employee,
                    request_type='leave',
                    from_date=app.from_date,
                    status='pending',
                ).update(
                    status='rejected',
                    approver=request.user,
                    rejection_reason=app.rejection_reason[:200],
                    decided_at=timezone.now(),
                )
                create_notification(
                    app.employee,
                    'Leave Rejected',
                    f'Your leave application ({app.application_no}) was rejected. Reason: {app.rejection_reason or "Not specified"}',
                    category='leave',
                    link='/leave/history/',
                )
                messages.warning(request, f'Leave rejected for {app.employee.get_full_name()}.')
        except LeaveApplication.DoesNotExist:
            pass
        return redirect('leave_tlapproval')

    if is_hr_or_admin(request.user):
        pending = LeaveApplication.objects.filter(status='pending', approval_stage='hr').order_by('-applied_on')
        tl_pending = LeaveApplication.objects.filter(status='pending', approval_stage='tl').order_by('-applied_on')[:10]
    elif is_team_leader(request.user):
        pending = LeaveApplication.objects.filter(
            status='pending',
            approval_stage='tl',
            employee__profile__reporting_manager=request.user,
        ).order_by('-applied_on')
        tl_pending = []
    else:
        messages.error(request, 'Access denied.')
        return redirect('dashboard')

    approved_count = LeaveApplication.objects.filter(status='approved', actioned_on__month=timezone.now().month).count()
    rejected_count = LeaveApplication.objects.filter(status='rejected', actioned_on__month=timezone.now().month).count()
    return render(request, 'Leave Management.html/TL approval.html', {
        'pending': pending,
        'tl_pending': tl_pending,
        'approved_count': approved_count,
        'rejected_count': rejected_count,
        'is_hr_admin': is_hr_or_admin(request.user),
        'is_team_leader': is_team_leader(request.user),
        'show_hr_queue': is_hr_or_admin(request.user),
    })


# ── Payroll ────────────────────────────────────────────────────────────────────
@login_required
def pay_history(request):
    records = EmployeeSalary.objects.filter(employee=request.user).order_by('-year', '-month')
    current_year = timezone.now().year
    ytd_records = records.filter(year=current_year)
    ytd_gross = sum(float(r.gross_salary) for r in ytd_records)
    ytd_deductions = sum(float(r.total_deductions) for r in ytd_records)
    ytd_net = sum(float(r.net_pay) for r in ytd_records)
    latest = records.first()
    annual_ctc = float(latest.gross_salary) * 12 if latest else 0
    return render(request, 'dashboard.html', {
        'payroll_records': records,
        'latest_salary': latest,
        'annual_ctc': annual_ctc,
        'ytd_gross': ytd_gross,
        'ytd_deductions': ytd_deductions,
        'ytd_net': ytd_net,
        'current_year': current_year,
        'active_page': 'pay-history',
    })


@login_required
def pay_bonus(request):
    bonuses = BonusRecord.objects.filter(employee=request.user).order_by('-awarded_on')
    total_bonus = sum(float(b.amount) for b in bonuses)
    return render(request, 'dashboard.html', {
        'bonuses': bonuses,
        'total_bonus': total_bonus,
        'active_page': 'pay-bonus',
    })


@login_required
def pay_payslip(request):
    records = EmployeeSalary.objects.filter(employee=request.user).order_by('-year', '-month')
    latest = records.first()
    try:
        emp_profile = request.user.profile
    except Exception:
        emp_profile = None
    return render(request, 'dashboard.html', {
        'payroll_records': records,
        'latest_salary': latest,
        'emp_profile': emp_profile,
        'active_page': 'pay-payslip',
    })


# ── Complaints ─────────────────────────────────────────────────────────────────
VALID_COMPLAINT_CATEGORIES = {c[0] for c in Complaint.CATEGORY_CHOICES}
VALID_COMPLAINT_PRIORITIES = {c[0] for c in Complaint.PRIORITY_CHOICES}


def _validate_complaint_payload(data):
    """Validate raw POST data for a complaint submission.
    Returns (cleaned_dict, errors_dict). errors_dict is empty when valid."""
    errors = {}
    cleaned = {}

    department = (data.get('department') or '').strip()
    if not department:
        errors['department'] = 'Department is required.'
    elif len(department) > 100:
        errors['department'] = 'Department name is too long (max 100 characters).'
    cleaned['department'] = department

    category = (data.get('category') or '').strip()
    if not category:
        errors['category'] = 'Please select a category.'
    elif category not in VALID_COMPLAINT_CATEGORIES:
        errors['category'] = 'Invalid category selected.'
    cleaned['category'] = category

    priority = (data.get('priority') or 'medium').strip()
    if priority not in VALID_COMPLAINT_PRIORITIES:
        errors['priority'] = 'Invalid priority selected.'
    cleaned['priority'] = priority

    subject = (data.get('subject') or '').strip()
    if not subject:
        errors['subject'] = 'Subject is required.'
    elif len(subject) > 200:
        errors['subject'] = 'Subject is too long (max 200 characters).'
    cleaned['subject'] = subject

    description = (data.get('description') or '').strip()
    if not description:
        errors['description'] = 'Description is required.'
    elif len(description) < 10:
        errors['description'] = 'Please provide a more detailed description (at least 10 characters).'
    cleaned['description'] = description

    cleaned['is_anonymous'] = str(data.get('is_anonymous', '')).lower() in ('on', 'true', '1', 'yes')

    return cleaned, errors


@login_required
def comp_raise(request):
    if request.method == 'POST':
        cleaned, errors = _validate_complaint_payload(request.POST)

        if errors:
            if _is_ajax(request):
                return JsonResponse({'success': False, 'errors': errors}, status=400)
            for msg in errors.values():
                messages.error(request, msg)
            return render(request, 'complaint management.html/Rasie complaint.html', {
                'form_errors': errors, 'form_data': request.POST,
            })

        complaint = Complaint.objects.create(
            employee=request.user,
            department=cleaned['department'],
            category=cleaned['category'],
            priority=cleaned['priority'],
            subject=cleaned['subject'],
            description=cleaned['description'],
            is_anonymous=cleaned['is_anonymous'],
        )

        try:
            notify_hr_admins(
                'New Complaint Raised',
                f'{request.user.get_full_name() or request.user.username} raised a complaint '
                f'({complaint.ticket_no}): {complaint.subject}',
                category='complaint',
                link='/complaints/hr-review/',
            )
        except Exception:
            pass

        if _is_ajax(request):
            return JsonResponse({
                'success': True,
                'message': 'Complaint submitted successfully!',
                'ticket_no': complaint.ticket_no,
                'redirect_url': '/complaints/track/',
            })

        messages.success(request, f"Complaint submitted successfully! Ticket #{complaint.ticket_no}")
        return redirect('comp_track')

    return render(request, 'complaint management.html/Rasie complaint.html', {})


@login_required
def comp_track(request):
    ticket = request.GET.get('ticket', '').strip()
    complaints = Complaint.objects.filter(employee=request.user).order_by('-created_at')
    found = None
    not_found = False
    if ticket:
        try:
            found = Complaint.objects.get(ticket_no=ticket, employee=request.user)
        except Complaint.DoesNotExist:
            not_found = True

    if _is_ajax(request):
        def serialize(c):
            return {
                'id': c.id,
                'ticket_no': c.ticket_no,
                'department': c.department,
                'category': c.get_category_display(),
                'priority': c.priority,
                'priority_display': c.get_priority_display(),
                'subject': c.subject,
                'description': c.description,
                'status': c.status,
                'status_display': c.get_status_display(),
                'is_anonymous': c.is_anonymous,
                'resolution_note': c.resolution_note,
                'created_at': c.created_at.strftime('%d %b %Y, %I:%M %p'),
                'updated_at': c.updated_at.strftime('%d %b %Y, %I:%M %p'),
            }
        return JsonResponse({
            'success': True,
            'complaints': [serialize(c) for c in complaints],
            'found': serialize(found) if found else None,
            'not_found': not_found,
            'search_ticket': ticket,
        })

    return render(request, 'complaint management.html/complant Tracking.html', {
        'complaints': complaints, 'found': found, 'search_ticket': ticket, 'not_found': not_found,
    })


@login_required
def comp_resolution(request):
    resolved = Complaint.objects.filter(employee=request.user, status='resolved')
    total_closed_count = Complaint.objects.filter(employee=request.user, status__in=['resolved', 'closed']).count()
    return render(request, 'complaint management.html/resoluation comments.html', {
        'resolved': resolved,
        'total_closed_count': total_closed_count,
    })


@login_required
@hr_admin_required
def comp_hrreview(request):
    if request.method == 'POST':
        comp_id = request.POST.get('comp_id')
        action = request.POST.get('action')
        try:
            comp = Complaint.objects.get(id=comp_id)
            if action == 'resolve':
                comp.status = 'resolved'
                comp.resolution_note = request.POST.get('resolution_note', '')
                comp.resolved_on = timezone.now()
                comp.save()
                messages.success(request, "Complaint marked as resolved.")
            elif action == 'escalate':
                comp.priority = 'urgent'
                comp.status = 'in_progress'
                comp.save()
                messages.warning(request, "Complaint escalated to management.")
            elif action == 'close':
                comp.status = 'closed'
                comp.save()
                messages.success(request, "Complaint closed.")
            elif action == 'assign':
                assignee_id = request.POST.get('assignee_id')
                comp.assigned_to_id = assignee_id or None
                comp.status = 'in_progress' if assignee_id else comp.status
                comp.save()
                messages.success(request, "Investigator assigned.")
            elif action == 'note':
                comp.resolution_note = request.POST.get('resolution_note', '')
                comp.save()
                messages.success(request, "Note saved.")
        except Complaint.DoesNotExist:
            pass
        return redirect(f"{request.path}?ticket={request.POST.get('ticket_no', '')}")

    all_complaints = Complaint.objects.all().order_by('-created_at')
    today = timezone.localtime(timezone.now()).date()

    selected_ticket = request.GET.get('ticket')
    selected = None
    if selected_ticket:
        selected = all_complaints.filter(ticket_no=selected_ticket).first()
    if not selected:
        selected = all_complaints.first()

    investigators = User.objects.filter(Q(is_staff=True) | Q(is_superuser=True)).distinct()

    return render(request, 'complaint management.html/HR review.html', {
        'complaints': all_complaints,
        'selected': selected,
        'investigators': investigators,
        'open_count': all_complaints.filter(status='open').count(),
        'inprogress_count': all_complaints.filter(status='in_progress').count(),
        'resolved_count': all_complaints.filter(status='resolved').count(),
        'resolved_this_month_count': all_complaints.filter(
            status='resolved', resolved_on__year=today.year, resolved_on__month=today.month
        ).count(),
        'total_count': all_complaints.count(),
    })


def _send_interview_email(interview, is_reschedule=False):
    app = interview.application
    subject = f"Interview {'Rescheduled' if is_reschedule else 'Scheduled'} – {app.job.title}"
    body = (
        f"Dear {app.candidate_name},\n\n"
        f"Your interview for {app.job.title} has been {'rescheduled' if is_reschedule else 'scheduled'}.\n\n"
        f"Round: {interview.get_round_display()}\n"
        f"Date: {interview.interview_date}\n"
        f"Time: {interview.interview_time}\n"
        f"Mode: {interview.get_mode_display()}\n"
        f"Interviewers: {interview.interviewers}\n\n"
        f"Notes: {interview.notes or 'N/A'}\n\n"
        f"Regards,\nEDGEPRO HR Team"
    )
    try:
        send_mail(
            subject,
            body,
            settings.DEFAULT_FROM_EMAIL,
            [app.candidate_email],
            fail_silently=not settings.DEBUG,
        )
        interview.email_sent = True
        interview.save(update_fields=['email_sent'])
    except Exception:
        pass


# ── Recruitment ────────────────────────────────────────────────────────────────
@login_required
def rec_jobs(request):
    if request.method == 'POST' and is_hr_or_admin(request.user):
        action = request.POST.get('action')
        if action == 'create_job':
            JobPosting.objects.create(
                title=request.POST.get('title', ''),
                department=request.POST.get('department', 'General'),
                location=request.POST.get('location', ''),
                employment_type=request.POST.get('employment_type', 'Full Time'),
                description=request.POST.get('description', ''),
                skills=request.POST.get('skills', ''),
                posted_by=request.user,
            )
            messages.success(request, 'Job posted successfully.')
            return redirect('rec_jobs')
        if action == 'update_status':
            job = get_object_or_404(JobPosting, id=request.POST.get('job_id'))
            job.status = request.POST.get('status', job.status)
            job.save()
            messages.success(request, 'Job status updated.')
            return redirect('rec_jobs')
    jobs = JobPosting.objects.all()
    return render(request, 'Recruitment.html/Job posting.html', {
        'jobs': jobs,
        'is_hr_admin': is_hr_or_admin(request.user),
    })


@login_required
def rec_resume(request):
    if request.method == 'POST':
        job_id = request.POST.get('job_id')
        job = get_object_or_404(JobPosting, id=job_id) if job_id else JobPosting.objects.filter(status='open').first()
        if not job:
            messages.error(request, 'No open job postings available.')
            return redirect('rec_resume')
        app = JobApplication.objects.create(
            job=job,
            referred_by=request.user if request.POST.get('app_type') == 'referral' else None,
            application_type=request.POST.get('app_type', 'self'),
            candidate_name=request.POST.get('candidate_name', ''),
            candidate_email=request.POST.get('candidate_email', ''),
            candidate_phone=request.POST.get('candidate_phone', ''),
            experience=request.POST.get('experience', ''),
            current_ctc=request.POST.get('current_ctc', ''),
            expected_ctc=request.POST.get('expected_ctc', ''),
            notice_period=request.POST.get('notice_period', '30 days'),
            cover_letter=request.POST.get('cover_letter', ''),
            resume=request.FILES.get('resume'),
        )
        if is_hr_or_admin(request.user):
            create_notification(
                request.user,
                'New Application Received',
                f'{app.candidate_name} applied for {job.title}.',
                category='recruitment',
                link='/recruitment/interview/',
                send_push=False,
            )
        messages.success(request, f"Resume submitted! Application {app.app_no} created.")
        return redirect('rec_resume')
    jobs = JobPosting.objects.filter(status='open')
    submitted = JobApplication.objects.filter(referred_by=request.user).order_by('-applied_on')[:10]
    return render(request, 'Recruitment.html/Resume Uplode.html', {
        'jobs': jobs,
        'submitted': submitted,
        'is_hr_admin': is_hr_or_admin(request.user),
    })


@login_required
def rec_interview(request):
    if request.method == 'POST' and is_hr_or_admin(request.user):
        action = request.POST.get('action', 'schedule')
        if action == 'schedule':
            app = get_object_or_404(JobApplication, id=request.POST.get('app_id'))
            interview = InterviewSchedule.objects.create(
                application=app,
                round=request.POST.get('round', 'hr_screen'),
                interview_date=request.POST.get('interview_date'),
                interview_time=request.POST.get('interview_time', '10:00'),
                mode=request.POST.get('mode', 'in_person'),
                interviewers=request.POST.get('interviewers', ''),
                notes=request.POST.get('notes', ''),
                scheduled_by=request.user,
            )
            app.status = 'interview'
            app.save(update_fields=['status'])
            _send_interview_email(interview)
            messages.success(request, 'Interview scheduled and email sent to candidate.')
            return redirect('rec_interview')
        if action == 'reschedule':
            old = get_object_or_404(InterviewSchedule, id=request.POST.get('interview_id'))
            new_iv = InterviewSchedule.objects.create(
                application=old.application,
                round=old.round,
                interview_date=request.POST.get('interview_date'),
                interview_time=request.POST.get('interview_time'),
                mode=old.mode,
                interviewers=old.interviewers,
                notes=old.notes,
                scheduled_by=request.user,
                rescheduled_from=old,
            )
            old.status = 'cancelled'
            old.save(update_fields=['status'])
            _send_interview_email(new_iv, is_reschedule=True)
            messages.success(request, 'Interview rescheduled and candidate notified.')
            return redirect('rec_interview')
        if action == 'update_status':
            interview = get_object_or_404(InterviewSchedule, id=request.POST.get('interview_id'))
            interview.status = request.POST.get('status', interview.status)
            interview.save()
            messages.success(request, 'Interview status updated.')
            return redirect('rec_interview')
        if action == 'update_app_status':
            app = get_object_or_404(JobApplication, id=request.POST.get('app_id'))
            app.status = request.POST.get('status', app.status)
            app.save()
            messages.success(request, 'Candidate status updated.')
            return redirect('rec_interview')
    upcoming = InterviewSchedule.objects.exclude(status='cancelled').order_by('interview_date', 'interview_time')[:20]
    applications = JobApplication.objects.select_related('job').all().order_by('-applied_on')[:30]
    return render(request, 'Recruitment.html/Interview Sheduling.html', {
        'upcoming': upcoming,
        'applications': applications,
        'is_hr_admin': is_hr_or_admin(request.user),
    })


# ── Workflow ───────────────────────────────────────────────────────────────────
@login_required
@hr_admin_required
def wf_approve(request):
    if request.method == 'POST':
        req_id = request.POST.get('req_id')
        action = request.POST.get('action')
        try:
            wf = WorkflowRequest.objects.get(id=req_id)
            if action == 'approve':
                wf.status = 'approved'
                wf.approver = request.user
                wf.decided_at = timezone.now()
                wf.save()
                if wf.request_type == 'leave':
                    leave_app = LeaveApplication.objects.filter(
                        employee=wf.employee,
                        from_date=wf.from_date,
                        status='pending',
                    ).first()
                    if leave_app and leave_app.approval_stage == 'hr' and is_hr_or_admin(request.user):
                        leave_app.status = 'approved'
                        leave_app.approver = request.user
                        leave_app.approval_stage = 'done'
                        leave_app.actioned_on = timezone.now()
                        leave_app.save()
                create_notification(
                    wf.employee,
                    'Workflow Request Approved',
                    f'Your {wf.get_request_type_display()} request has been approved.',
                    category='workflow',
                    link='/workflow/history/',
                )
                messages.success(request, "Request approved!")
            elif action == 'reject':
                wf.status = 'rejected'
                wf.approver = request.user
                wf.rejection_reason = request.POST.get('reason', '')
                wf.decided_at = timezone.now()
                wf.save()
                create_notification(
                    wf.employee,
                    'Workflow Request Rejected',
                    f'Your {wf.get_request_type_display()} request was rejected. Reason: {wf.rejection_reason}',
                    category='workflow',
                    link='/workflow/history/',
                )
                messages.warning(request, "Request rejected.")
        except WorkflowRequest.DoesNotExist:
            pass
        return redirect('wf_approve')
    pending = WorkflowRequest.objects.filter(status='pending').order_by('-created_at')
    month = timezone.now().month
    return render(request, 'work flow.html/approve.html', {
        'pending': pending,
        'approved_count': WorkflowRequest.objects.filter(status='approved', decided_at__month=month).count(),
        'rejected_count': WorkflowRequest.objects.filter(status='rejected', decided_at__month=month).count(),
    })


@login_required
@hr_admin_required
def wf_reject(request):
    pending = WorkflowRequest.objects.filter(status='pending').order_by('-created_at')
    return render(request, 'work flow.html/reject.html', {'pending': pending})


@login_required
def wf_history(request):
    req_type = request.GET.get('type', '')
    status = request.GET.get('status', '')
    history = WorkflowRequest.objects.exclude(status='pending')
    if not is_hr_or_admin(request.user):
        history = history.filter(employee=request.user)
    if req_type:
        history = history.filter(request_type=req_type)
    if status:
        # Filter by request status safely
        valid_statuses = ['pending', 'approved', 'rejected']
        if status and status in valid_statuses:
            history = history.filter(status=status)
    history = history.order_by('-decided_at', '-created_at')
    return render(request, 'dashboard.html', {
        'workflow_history': history,
        'is_hr_admin': is_hr_or_admin(request.user),
        'active_page': 'wf-history',
    })


@login_required
def wf_notifications(request):
    from .models import NotificationPreference
    prefs, _ = NotificationPreference.objects.get_or_create(user=request.user)
    if request.method == 'POST':
        prefs.email_enabled = request.POST.get('email_enabled') == 'on'
        prefs.push_enabled = request.POST.get('push_enabled') == 'on'
        prefs.weekly_digest = request.POST.get('weekly_digest') == 'on'
        prefs.save()
        messages.success(request, "Notification preferences saved!")
        return redirect('notification_preferences')
    return redirect('notification_preferences')


# ── Work Tracking ──────────────────────────────────────────────────────────────
@login_required
def wt_daily(request):
    if request.method == 'POST':
        date_str = request.POST.get('date', str(timezone.localtime(timezone.now()).date()))
        from datetime import date as dt
        DailyWorkUpdate.objects.update_or_create(
            employee=request.user, date=date_str,
            defaults={
                'hours_worked': request.POST.get('hours_worked', 8),
                'tasks_completed': request.POST.get('tasks_completed', ''),
                'tasks_in_progress': request.POST.get('tasks_in_progress', ''),
                'planned_tomorrow': request.POST.get('planned_tomorrow', ''),
            }
        )
        messages.success(request, "Daily update submitted!")
        return redirect('wt_daily')
    week_updates = DailyWorkUpdate.objects.filter(employee=request.user).order_by('-date')[:5]
    return render(request, 'work  tracking.html/daily  work update.html', {
        'week_updates': week_updates, 'today': timezone.localtime(timezone.now()).date(),
    })


@login_required
def wt_time(request):
    if request.method == 'POST':
        project_id = request.POST.get('project_id')
        project = None
        if project_id:
            try:
                project = Project.objects.get(id=project_id)
            except Project.DoesNotExist:
                pass
        TimeEntry.objects.create(
            employee=request.user,
            project=project,
            task_description=request.POST.get('task_description', ''),
            date=request.POST.get('date', str(timezone.localtime(timezone.now()).date())),
            start_time=request.POST.get('start_time', '09:00'),
            end_time=request.POST.get('end_time', '18:00'),
            hours=request.POST.get('hours', 8),
            is_billable=request.POST.get('is_billable') != 'no',
        )
        messages.success(request, "Time entry logged!")
        return redirect('wt_time')
    week_entries = TimeEntry.objects.filter(employee=request.user).order_by('-date')[:10]
    projects = Project.objects.all()
    return render(request, 'work  tracking.html/time tracking.html', {
        'week_entries': week_entries, 'projects': projects,
        'total_hours': sum(float(e.hours) for e in week_entries),
        'today': timezone.localtime(timezone.now()).date(),
    })


# ── Time Management (My Timesheet / Timesheet List) ────────────────────────────
@login_required
def timesheet_my(request):
    if request.method == 'POST':
        project_id = request.POST.get('project_id')
        project = None
        if project_id:
            try:
                project = Project.objects.get(id=project_id)
            except Project.DoesNotExist:
                pass
        TimeEntry.objects.create(
            employee=request.user,
            project=project,
            task_description=request.POST.get('task_description', ''),
            date=request.POST.get('date', str(timezone.localtime(timezone.now()).date())),
            start_time=request.POST.get('start_time', '09:00'),
            end_time=request.POST.get('end_time', '18:00'),
            hours=request.POST.get('hours', 8),
            is_billable=request.POST.get('is_billable') != 'no',
            location=request.POST.get('location', ''),
        )
        messages.success(request, "Timesheet entry submitted!")
        return redirect('timesheet_my')
    week_entries = TimeEntry.objects.filter(employee=request.user).order_by('-date')[:10]
    projects = Project.objects.all()
    return render(request, 'Time Management.html/My Timesheet.html', {
        'week_entries': week_entries, 'projects': projects,
        'total_hours': sum(float(e.hours) for e in week_entries),
        'today': timezone.localtime(timezone.now()).date(),
    })


@login_required
def timesheet_list(request):
    if request.user.is_staff or request.user.is_superuser:
        entries = TimeEntry.objects.all().select_related('employee', 'project').order_by('-date')
    else:
        entries = TimeEntry.objects.filter(employee=request.user).order_by('-date')

    employee_id = request.GET.get('employee')
    emp_code = request.GET.get('employee_id', '').strip()
    date_from = request.GET.get('date_from')
    date_to = request.GET.get('date_to')
    searched_employee_not_found = False
    if emp_code and (request.user.is_staff or request.user.is_superuser):
        try:
            target_profile = EmployeeProfile.objects.get(employee_id__iexact=emp_code)
            entries = entries.filter(employee=target_profile.user)
        except EmployeeProfile.DoesNotExist:
            entries = entries.none()
            searched_employee_not_found = True
    elif employee_id:
        entries = entries.filter(employee_id=employee_id)
    if date_from:
        entries = entries.filter(date__gte=date_from)
    if date_to:
        entries = entries.filter(date__lte=date_to)

    entries = entries[:200]
    return render(request, 'Time Management.html/Timesheet List.html', {
        'entries': entries,
        'total_hours': sum(float(e.hours) for e in entries),
        'is_manager_view': request.user.is_staff or request.user.is_superuser,
        'employees': User.objects.all() if (request.user.is_staff or request.user.is_superuser) else None,
        'searched_employee_not_found': searched_employee_not_found,
    })


@login_required
@hr_admin_required
def wt_taskassign(request):
    if request.method == 'POST':
        project_id = request.POST.get('project_id')
        project = None
        if project_id:
            try:
                project = Project.objects.get(id=project_id)
            except Project.DoesNotExist:
                pass
        assignee_id = request.POST.get('assigned_to')
        assignee = None
        if assignee_id:
            try:
                assignee = User.objects.get(id=assignee_id)
            except User.DoesNotExist:
                pass
        task = Task.objects.create(
            title=request.POST.get('title', ''),
            description=request.POST.get('description', ''),
            project=project,
            assigned_by=request.user,
            assigned_to=assignee,
            priority=request.POST.get('priority', 'medium'),
            start_date=request.POST.get('start_date') or None,
            due_date=request.POST.get('due_date') or None,
            estimated_hours=request.POST.get('estimated_hours') or None,
        )
        if assignee:
            create_notification(
                assignee,
                'New Task Assigned',
                f'You have been assigned: {task.title}',
                category='general',
                link='/work-tracking/assigned-tasks/',
            )
        messages.success(request, "Task assigned successfully!")
        return redirect('wt_taskassign')
    my_tasks = Task.objects.filter(assigned_by=request.user).order_by('-created_at')[:20]
    users = User.objects.filter(is_active=True)
    projects = Project.objects.all()
    return render(request, 'work  tracking.html/task assigment.html', {
        'my_tasks': my_tasks, 'users': users, 'projects': projects,
    })


@login_required
def wt_assigned_tasks(request):
    """Employee view: tasks assigned to the logged-in user."""
    if request.method == 'POST':
        task_id = request.POST.get('task_id')
        new_status = request.POST.get('status')
        try:
            task = Task.objects.get(id=task_id, assigned_to=request.user)
            task.status = new_status
            task.save()
            messages.success(request, 'Task status updated!')
        except Task.DoesNotExist:
            messages.error(request, 'Task not found or access denied.')
        return redirect('wt_assigned_tasks')
    todo = Task.objects.filter(assigned_to=request.user, status='todo')
    in_progress = Task.objects.filter(assigned_to=request.user, status='in_progress')
    completed = Task.objects.filter(assigned_to=request.user, status='completed')[:10]
    return render(request, 'work  tracking.html/task progess.html', {
        'todo': todo,
        'in_progress': in_progress,
        'completed': completed,
        'is_hr_admin': is_hr_or_admin(request.user),
        'page_title': 'My Assigned Tasks',
    })


@login_required
@hr_admin_required
def wt_taskprogress(request):
    """HR/Admin view: all team tasks."""
    if request.method == 'POST':
        task_id = request.POST.get('task_id')
        new_status = request.POST.get('status')
        try:
            task = Task.objects.get(id=task_id)
            task.status = new_status
            task.save()
            if task.assigned_to:
                create_notification(
                    task.assigned_to,
                    'Task Status Updated',
                    f'Task "{task.title}" status changed to {task.get_status_display()}.',
                    category='general',
                    link='/work-tracking/assigned-tasks/',
                    send_email=False,
                )
            messages.success(request, 'Task status updated!')
        except Task.DoesNotExist:
            pass
        return redirect('wt_taskprogress')
    todo = Task.objects.filter(status='todo')
    in_progress = Task.objects.filter(status='in_progress')
    completed = Task.objects.filter(status='completed')[:20]
    return render(request, 'work  tracking.html/task progess.html', {
        'todo': todo,
        'in_progress': in_progress,
        'completed': completed,
        'is_hr_admin': True,
        'page_title': 'Team Task Progress',
    })


@login_required
def wt_projectstatus(request):
    if request.method == 'POST' and is_hr_or_admin(request.user):
        action = request.POST.get('action', 'create')
        if action == 'create':
            Project.objects.create(
                name=request.POST.get('name', ''),
                description=request.POST.get('description', ''),
                manager=request.user,
                start_date=request.POST.get('start_date'),
                due_date=request.POST.get('due_date'),
                progress=int(request.POST.get('progress', 0) or 0),
                status=request.POST.get('status', 'on_track'),
            )
            messages.success(request, 'Project created.')
        elif action == 'update':
            project = get_object_or_404(Project, id=request.POST.get('project_id'))
            project.name = request.POST.get('name', project.name)
            project.progress = int(request.POST.get('progress', project.progress) or 0)
            project.status = request.POST.get('status', project.status)
            project.save()
            messages.success(request, 'Project updated.')
        return redirect('wt_projectstatus')

    if is_hr_or_admin(request.user):
        projects = Project.objects.all()
    else:
        projects = Project.objects.filter(
            Q(team_members=request.user) | Q(manager=request.user)
        ).distinct()
    return render(request, 'work  tracking.html/poject states.html', {
        'projects': projects,
        'on_track': projects.filter(status='on_track').count(),
        'at_risk': projects.filter(status='at_risk').count(),
        'delayed': projects.filter(status='delayed').count(),
        'is_hr_admin': is_hr_or_admin(request.user),
    })


# ── Profile ────────────────────────────────────────────────────────────────────
@login_required
def profile(request):
    try:
        emp_profile = request.user.profile
    except Exception:
        emp_profile = None
    if request.method == 'POST':
        user = request.user
        # Full name split
        full_name = request.POST.get('full_name', '').strip()
        if full_name:
            parts = full_name.split(' ', 1)
            user.first_name = parts[0]
            user.last_name = parts[1] if len(parts) > 1 else ''
        user.email = request.POST.get('email', user.email)
        user.save()
        if emp_profile:
            emp_profile.phone = request.POST.get('phone', emp_profile.phone)
            emp_profile.address = request.POST.get('address', emp_profile.address)
            emp_profile.gender = request.POST.get('gender', emp_profile.gender)
            emp_profile.blood_group = request.POST.get('blood_group', emp_profile.blood_group)
            emp_profile.emergency_contact_name = request.POST.get('emergency_contact_name', emp_profile.emergency_contact_name)
            emp_profile.emergency_contact_phone = request.POST.get('emergency_contact_phone', emp_profile.emergency_contact_phone)
            dob = request.POST.get('date_of_birth', '')
            if dob:
                from datetime import date
                try:
                    emp_profile.date_of_birth = date.fromisoformat(dob)
                except ValueError:
                    pass
            emp_profile.save()
        messages.success(request, "Profile updated successfully!")
        return redirect('profile')
    return render(request, 'dashboard.html', {'emp_profile': emp_profile, 'active_page': 'profile'})


# ── Settings ───────────────────────────────────────────────────────────────────
@login_required
def settings_view(request):
    if request.method == 'POST':
        action = request.POST.get('action', '')
        if action == 'change_password':
            from django.contrib.auth import update_session_auth_hash
            from django.contrib.auth.forms import PasswordChangeForm
            form = PasswordChangeForm(request.user, request.POST)
            if form.is_valid():
                user = form.save()
                update_session_auth_hash(request, user)
                messages.success(request, "Password updated successfully")
            else:
                messages.error(request, "Password update failed. Please check your entries.")
        else:
            user = request.user
            user.first_name = request.POST.get('display_name', user.first_name)
            user.email = request.POST.get('email', user.email)
            user.save()
            messages.success(request, "Account settings saved!")
        return redirect('settings')
    return render(request, 'dashboard.html', {'active_page': 'settings'})


# ── Document Upload (legacy redirect) ───────────────────────────────────────────
@login_required
def upload_document(request):
    return redirect('doc_upload')


# ── HR Register ────────────────────────────────────────────────────────────────
def register_hr(request):
    return redirect('register')


def register_admin(request):
    return redirect('register')