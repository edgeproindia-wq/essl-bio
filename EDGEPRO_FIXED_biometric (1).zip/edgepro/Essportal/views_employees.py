"""
views_employees.py
────────────────────
HR/Admin-facing employee management: add, edit, deactivate, reactivate,
and delete employees. All views here require HR or Admin privileges
(enforced by @hr_admin_required, same decorator used across the app).

Design choice — deactivate vs delete:
    Deactivating (User.is_active = False) is the normal, safe way to remove
    someone who has left the company. It keeps their entire attendance/leave/
    payroll/complaint history intact for audits, and they simply stop
    appearing in active-employee lists (the app already filters is_active=True
    everywhere it lists staff).

    Deleting actually removes the User row, which CASCADES and permanently
    wipes every AttendanceRecord, LeaveApplication, Complaint, etc. tied to
    them (see models.py — these all use on_delete=models.CASCADE). This is
    only meant for accidental/duplicate/test accounts, never a real employee
    who has left. The delete view requires typing the exact username to
    confirm, specifically to prevent an accidental click from destroying
    real history.
"""
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.core.paginator import Paginator
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from .models import EmployeeProfile, LeaveBalance
from .permissions import hr_admin_required

DEFAULT_PASSWORD = "Edgepro@123"  # same default already used across the portal


@login_required
@hr_admin_required
def employee_list(request):
    """Directory of all employees with search + active/inactive filter."""
    query = request.GET.get('q', '').strip()
    status_filter = request.GET.get('status', 'active')  # active | inactive | all

    users = User.objects.select_related('profile').all().order_by('first_name', 'username')

    if status_filter == 'active':
        users = users.filter(is_active=True)
    elif status_filter == 'inactive':
        users = users.filter(is_active=False)
    # 'all' -> no filter

    if query:
        users = users.filter(
            Q(first_name__icontains=query) |
            Q(last_name__icontains=query) |
            Q(username__icontains=query) |
            Q(email__icontains=query) |
            Q(profile__employee_id__icontains=query) |
            Q(profile__department__icontains=query)
        )

    paginator = Paginator(users, 25)
    page_obj = paginator.get_page(request.GET.get('page'))

    return render(request, 'Employee Management/employee_list.html', {
        'page_obj': page_obj,
        'query': query,
        'status_filter': status_filter,
        'total_active': User.objects.filter(is_active=True).count(),
        'total_inactive': User.objects.filter(is_active=False).count(),
    })


@login_required
@hr_admin_required
def employee_add(request):
    """Add a single employee (HR-driven, explicit Emp Code — different from
    the public self-registration flow in views_auth.register_unified)."""
    if request.method == 'POST':
        emp_code = request.POST.get('employee_id', '').strip()
        first_name = request.POST.get('first_name', '').strip()
        last_name = request.POST.get('last_name', '').strip()
        email = request.POST.get('email', '').strip()
        department = request.POST.get('department', '').strip()
        designation = request.POST.get('designation', '').strip()
        work_location = request.POST.get('work_location', '').strip()

        errors = []
        if not emp_code:
            errors.append('Emp Code is required.')
        elif User.objects.filter(username=emp_code).exists():
            errors.append(f'An account with Emp Code "{emp_code}" already exists.')
        if not first_name:
            errors.append('First name is required.')
        if email and User.objects.filter(email__iexact=email).exists():
            errors.append('An account with this email already exists.')

        if errors:
            for e in errors:
                messages.error(request, e)
            return render(request, 'Employee Management/employee_add.html', {'form_data': request.POST})

        user = User.objects.create_user(
            username=emp_code,
            password=DEFAULT_PASSWORD,
            first_name=first_name,
            last_name=last_name,
            email=email,
        )
        user.is_active = True
        user.save()

        EmployeeProfile.objects.create(
            user=user,
            employee_id=emp_code,
            department=department,
            designation=designation,
            work_location=work_location,
            date_of_joining=timezone.localdate(),
            registration_status='approved',
            approved_by=request.user,
            approved_at=timezone.now(),
        )
        LeaveBalance.objects.get_or_create(employee=user)

        messages.success(
            request,
            f'Employee "{first_name} {last_name}" added. '
            f'Login — Username: {emp_code}  Password: {DEFAULT_PASSWORD}'
        )
        return redirect('employee_list')

    return render(request, 'Employee Management/employee_add.html', {'form_data': {}})


@login_required
@hr_admin_required
def employee_edit(request, user_id):
    emp_user = get_object_or_404(User.objects.select_related('profile'), id=user_id)
    profile = getattr(emp_user, 'profile', None)

    if request.method == 'POST':
        emp_user.first_name = request.POST.get('first_name', '').strip()
        emp_user.last_name = request.POST.get('last_name', '').strip()
        emp_user.email = request.POST.get('email', '').strip()
        emp_user.save()

        if profile:
            profile.department = request.POST.get('department', '').strip()
            profile.designation = request.POST.get('designation', '').strip()
            profile.work_location = request.POST.get('work_location', '').strip()
            profile.phone = request.POST.get('phone', '').strip()
            profile.save()

        messages.success(request, f'Updated {emp_user.get_full_name() or emp_user.username}.')
        return redirect('employee_list')

    return render(request, 'Employee Management/employee_edit.html', {
        'emp_user': emp_user,
        'profile': profile,
    })


@login_required
@hr_admin_required
def employee_deactivate(request, user_id):
    """Soft-delete: sets is_active=False. History stays intact."""
    emp_user = get_object_or_404(User, id=user_id)

    if emp_user.id == request.user.id:
        messages.error(request, "You can't deactivate your own account.")
        return redirect('employee_list')

    if request.method == 'POST':
        emp_user.is_active = False
        emp_user.save()
        messages.success(request, f'{emp_user.get_full_name() or emp_user.username} has been deactivated.')
        return redirect('employee_list')

    return render(request, 'Employee Management/confirm_deactivate.html', {'emp_user': emp_user})


@login_required
@hr_admin_required
def employee_reactivate(request, user_id):
    emp_user = get_object_or_404(User, id=user_id)
    if request.method == 'POST':
        emp_user.is_active = True
        emp_user.save()
        messages.success(request, f'{emp_user.get_full_name() or emp_user.username} has been reactivated.')
    return redirect('employee_list')


@login_required
@hr_admin_required
def employee_delete(request, user_id):
    """
    PERMANENT delete — wipes the User row and, via CASCADE, every
    AttendanceRecord/LeaveApplication/Complaint/etc. tied to them.
    Requires typing the exact username to confirm. Use deactivate instead
    for anyone who has genuinely left the company.
    """
    emp_user = get_object_or_404(User, id=user_id)

    if emp_user.id == request.user.id:
        messages.error(request, "You can't delete your own account.")
        return redirect('employee_list')

    if request.method == 'POST':
        typed_username = request.POST.get('confirm_username', '').strip()
        if typed_username != emp_user.username:
            messages.error(request, 'Username did not match. Nothing was deleted.')
            return render(request, 'Employee Management/confirm_delete.html', {'emp_user': emp_user})

        username = emp_user.username
        emp_user.delete()
        messages.success(request, f'Employee "{username}" and all related records were permanently deleted.')
        return redirect('employee_list')

    return render(request, 'Employee Management/confirm_delete.html', {'emp_user': emp_user})
