from django.urls import path

from . import views
from . import views_biometric
from . import views_documents
from . import views_employees
from . import views_exports
from . import views_notifications

urlpatterns = [
    # Auth
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('register/', views.register, name='register'),
    path('register/hr/', views.register_hr, name='register_hr'),
    path('register/admin/', views.register_admin, name='register_admin'),
    path('forgot-password/', views.forgot_password, name='forgot_password'),

    # Dashboard
    path('', views.dashboard, name='dashboard'),

    # Announcements
    path('announcements/', views.announcement_list, name='announcement_list'),
    path('announcements/create/', views.announcement_create, name='announcement_create'),
    path('announcements/manage/', views.announcement_dashboard, name='announcement_dashboard'),
    path('announcements/<slug:slug>/', views.announcement_detail, name='announcement_detail'),
    path('announcements/<slug:slug>/edit/', views.announcement_edit, name='announcement_edit'),
    path('announcements/<slug:slug>/delete/', views.announcement_delete, name='announcement_delete'),
    path('announcements/<slug:slug>/toggle-pin/', views.toggle_pin, name='toggle_pin'),
    path('category/<slug:slug>/', views.category_announcements, name='category_announcements'),

    # Attendance
    path('attendance/checkin/', views.att_checkin, name='att_checkin'),
    path('attendance/checkout/', views.att_checkout, name='att_checkout'),
    path('attendance/late/', views.att_late, name='att_late'),
    path('attendance/late/approve/', views.att_approve_late, name='att_approve_late'),
    path('attendance/monthly/', views.att_monthly, name='att_monthly'),

    # Biometric integration
    path('api/biometric/sync/', views_biometric.biometric_sync_endpoint, name='biometric_sync_endpoint'),
    path('attendance/biometric/dashboard/', views_biometric.biometric_dashboard, name='biometric_dashboard'),

    # Employee Management (HR/Admin only)
    path('employees/', views_employees.employee_list, name='employee_list'),
    path('employees/add/', views_employees.employee_add, name='employee_add'),
    path('employees/<int:user_id>/edit/', views_employees.employee_edit, name='employee_edit'),
    path('employees/<int:user_id>/deactivate/', views_employees.employee_deactivate, name='employee_deactivate'),
    path('employees/<int:user_id>/reactivate/', views_employees.employee_reactivate, name='employee_reactivate'),
    path('employees/<int:user_id>/delete/', views_employees.employee_delete, name='employee_delete'),

    # Leave
    path('leave/apply/', views.leave_apply, name='leave_apply'),
    path('leave/draft/save/', views.leave_draft_save, name='leave_draft_save'),
    path('leave/draft/list/', views.leave_draft_list, name='leave_draft_list'),
    path('leave/draft/<int:draft_id>/delete/', views.leave_draft_delete, name='leave_draft_delete'),
    path('leave/casual/', views.leave_casual, name='leave_casual'),
    path('leave/sick/', views.leave_sick, name='leave_sick'),
    path('leave/history/', views.leave_history, name='leave_history'),
    path('leave/summary/', views.leave_summary, name='leave_summary'),
    path('leave/summary/daily/', views.leave_summary_daily, name='leave_summary_daily'),
    path('leave/summary/weekly/', views.leave_summary_weekly, name='leave_summary_weekly'),
    path('leave/summary/monthly/', views.leave_summary_monthly, name='leave_summary_monthly'),
    path('leave/tl-approval/', views.leave_tlapproval, name='leave_tlapproval'),

    # Payroll
    path('payroll/history/', views.pay_history, name='pay_history'),
    path('payroll/bonus/', views.pay_bonus, name='pay_bonus'),
    path('payroll/payslip/', views.pay_payslip, name='pay_payslip'),

    # Complaints
    path('complaints/raise/', views.comp_raise, name='comp_raise'),
    path('complaints/track/', views.comp_track, name='comp_track'),
    path('complaints/resolution/', views.comp_resolution, name='comp_resolution'),
    path('complaints/hr-review/', views.comp_hrreview, name='comp_hrreview'),

    # Recruitment
    path('recruitment/jobs/', views.rec_jobs, name='rec_jobs'),
    path('recruitment/resume/', views.rec_resume, name='rec_resume'),
    path('recruitment/interview/', views.rec_interview, name='rec_interview'),

    # Workflow
    path('workflow/approve/', views.wf_approve, name='wf_approve'),
    path('workflow/reject/', views.wf_reject, name='wf_reject'),
    path('workflow/history/', views.wf_history, name='wf_history'),
    path('workflow/notifications/', views.wf_notifications, name='wf_notifications'),

    # Work Tracking
    path('work-tracking/daily/', views.wt_daily, name='wt_daily'),
    path('work-tracking/time/', views.wt_time, name='wt_time'),
    path('work-tracking/task-assign/', views.wt_taskassign, name='wt_taskassign'),
    path('work-tracking/assigned-tasks/', views.wt_assigned_tasks, name='wt_assigned_tasks'),
    path('work-tracking/task-progress/', views.wt_taskprogress, name='wt_taskprogress'),
    path('work-tracking/project-status/', views.wt_projectstatus, name='wt_projectstatus'),

    # Time Management
    path('timesheet/my/', views.timesheet_my, name='timesheet_my'),
    path('timesheet/list/', views.timesheet_list, name='timesheet_list'),

    # Document Management
    path('documents/', views_documents.doc_list, name='doc_list'),
    path('documents/upload/', views_documents.doc_upload, name='doc_upload'),
    path('documents/<int:doc_id>/edit/', views_documents.doc_edit, name='doc_edit'),
    path('documents/<int:doc_id>/delete/', views_documents.doc_delete, name='doc_delete'),
    path('documents/<int:doc_id>/download/', views_documents.doc_download, name='doc_download'),
    path('upload-document/', views.upload_document, name='upload_document'),

    # Notifications
    path('notifications/', views_notifications.notification_list, name='notification_list'),
    path('notifications/preferences/', views_notifications.notification_preferences, name='notification_preferences'),
    path('notifications/api/', views_notifications.notification_api, name='notification_api'),
    path('notifications/<int:notif_id>/read/', views_notifications.notification_mark_read, name='notification_mark_read'),
    path('notifications/mark-all-read/', views_notifications.notification_mark_all_read, name='notification_mark_all_read'),
    path('notifications/push-token/', views_notifications.register_push_token, name='register_push_token'),

    # Exports
    path('export/leave/', views_exports.export_leave, name='export_leave'),
    path('export/attendance/', views_exports.export_attendance, name='export_attendance'),
    path('export/complaints/', views_exports.export_complaints, name='export_complaints'),
    path('export/recruitment/', views_exports.export_recruitment, name='export_recruitment'),
    path('export/announcements/', views_exports.export_announcements, name='export_announcements'),

    # Profile & Settings
    path('profile/', views.profile, name='profile'),
    path('settings/', views.settings_view, name='settings'),
]
