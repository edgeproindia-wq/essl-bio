"""Authentication helpers: unified registration and password reset."""

from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.forms import SetPasswordForm, UserCreationForm
from django.contrib.auth.models import User
from django.shortcuts import redirect, render
from django.utils import timezone

from .models import EmployeeProfile, LeaveBalance


def _redirect_for_role(user):
    return redirect('dashboard')


def infer_role_from_email(email):
    """Detect account role from work email — no manual selection required."""
    email_lower = email.lower().strip()
    local = email_lower.split('@')[0] if '@' in email_lower else email_lower

    admin_locals = {'admin', 'administrator', 'sysadmin', 'root'}
    hr_locals = {'hr', 'hrmanager', 'hr.manager', 'humanresources', 'human.resources'}

    if local in admin_locals or local.startswith('admin'):
        return 'admin'
    if local in hr_locals or local.startswith('hr') or local.startswith('hr.'):
        return 'hr'
    return 'employee'


def forgot_password(request):
    if request.user.is_authenticated:
        return redirect('dashboard')

    step = 'email'
    email = request.POST.get('email', '').strip() if request.method == 'POST' else ''

    if request.method == 'POST':
        step = request.POST.get('step', 'email')
        if step == 'email':
            user = User.objects.filter(email__iexact=email).first()
            if not user:
                user = User.objects.filter(username__iexact=email).first()
            if user:
                request.session['reset_user_id'] = user.id
                step = 'password'
            else:
                messages.error(request, 'No account found with that email address.')
        elif step == 'password':
            uid = request.session.get('reset_user_id')
            try:
                user = User.objects.get(id=uid)
            except User.DoesNotExist:
                messages.error(request, 'Session expired. Please enter your email again.')
                step = 'email'
            else:
                form = SetPasswordForm(user, request.POST)
                if form.is_valid():
                    form.save()
                    request.session.pop('reset_user_id', None)
                    messages.success(request, 'Password updated successfully. You can sign in now.')
                    return redirect('login')
                messages.error(request, 'Please fix the errors below and try again.')
                return render(request, 'forgot_password.html', {
                    'step': 'password',
                    'email': user.email or user.username,
                    'form': form,
                })

    return render(request, 'forgot_password.html', {'step': step, 'email': email})


def register_unified(request):
    if request.user.is_authenticated:
        return _redirect_for_role(request.user)

    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        email = request.POST.get('email', '').strip()
        role = infer_role_from_email(email) if email else 'employee'

        if not email:
            form.add_error(None, 'Email address is required.')
        elif User.objects.filter(email__iexact=email).exists():
            form.add_error(None, 'An account with this email already exists.')

        if form.is_valid() and email:
            user = form.save(commit=False)
            user.first_name = request.POST.get('first_name', '')
            user.last_name = request.POST.get('last_name', '')
            user.email = email
            user.is_active = True

            if role == 'hr':
                user.is_staff = True
            elif role == 'admin':
                user.is_staff = True
                user.is_superuser = True

            user.save()

            department = request.POST.get('department', 'General')
            designation = request.POST.get('designation', '')

            if role == 'employee':
                emp_id = f"EMP-{timezone.now().year}-{str(user.id).zfill(4)}"
                if not designation:
                    designation = 'Employee'
            elif role == 'hr':
                emp_id = f"HR-{timezone.now().year}-{str(user.id).zfill(4)}"
                department = department or 'HR'
                designation = designation or 'HR Manager'
            else:
                emp_id = f"ADM-{timezone.now().year}-{str(user.id).zfill(4)}"
                department = department or 'Administration'
                designation = designation or 'Administrator'

            EmployeeProfile.objects.get_or_create(
                user=user,
                defaults={
                    'employee_id': emp_id,
                    'department': department,
                    'designation': designation,
                    'registration_status': 'approved',
                    'approved_at': timezone.now(),
                },
            )
            if role == 'employee':
                LeaveBalance.objects.get_or_create(employee=user)

            login(request, user)
            role_labels = {'employee': 'Employee', 'hr': 'HR Manager', 'admin': 'Administrator'}
            messages.success(
                request,
                f'Welcome to EDGEPRO! Your account was set up as {role_labels.get(role, "Employee")} based on your email.',
            )
            return _redirect_for_role(user)
    else:
        form = UserCreationForm()

    return render(request, 'register.html', {'form': form})
