from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.http import FileResponse, Http404
from django.shortcuts import get_object_or_404, redirect, render

from .models import EmployeeDocument, EmployeeProfile
from .notifications import create_notification
from .permissions import is_hr_or_admin


def _sync_profile_flags(profile, doc_type):
    if doc_type == 'aadhar':
        profile.aadhar_verified = True
    elif doc_type == 'pan':
        profile.pan_verified = True
    elif doc_type == 'offer_letter':
        profile.offer_letter_uploaded = True
    elif doc_type == 'education_cert':
        profile.education_cert_uploaded = True
    elif doc_type == 'experience_letter':
        profile.experience_letter_uploaded = True
    profile.save()


@login_required
def doc_list(request):
    if is_hr_or_admin(request.user):
        employee_id = request.GET.get('employee')
        if employee_id:
            docs = EmployeeDocument.objects.filter(employee_id=employee_id)
            selected_employee = get_object_or_404(User, id=employee_id)
        else:
            docs = EmployeeDocument.objects.all()
            selected_employee = None
        employees = User.objects.filter(is_active=True).order_by('first_name', 'username')
    else:
        docs = EmployeeDocument.objects.filter(employee=request.user)
        employees = None
        selected_employee = None
    return render(request, 'Document Management/doc_list.html', {
        'documents': docs,
        'employees': employees,
        'selected_employee': selected_employee,
        'is_hr_admin': is_hr_or_admin(request.user),
    })


@login_required
def doc_upload(request):
    if request.method == 'POST':
        doc_type = request.POST.get('doc_type', 'other')
        title = request.POST.get('title', '').strip() or doc_type.replace('_', ' ').title()
        description = request.POST.get('description', '')
        doc_file = request.FILES.get('document_file')

        if is_hr_or_admin(request.user):
            employee = get_object_or_404(User, id=request.POST.get('employee_id'))
        else:
            employee = request.user

        if not doc_file:
            messages.error(request, 'Please select a file to upload.')
            return redirect('doc_upload')

        doc = EmployeeDocument.objects.create(
            employee=employee,
            doc_type=doc_type,
            title=title,
            file=doc_file,
            description=description,
            uploaded_by=request.user,
        )
        try:
            profile = employee.profile
            _sync_profile_flags(profile, doc_type)
        except EmployeeProfile.DoesNotExist:
            pass

        if employee != request.user:
            create_notification(
                employee,
                'New document uploaded',
                f'HR uploaded "{title}" to your document vault.',
                category='document',
                link='/documents/',
            )
        messages.success(request, 'Document uploaded successfully.')
        return redirect('doc_list')

    employees = User.objects.filter(is_active=True).order_by('first_name') if is_hr_or_admin(request.user) else None
    return render(request, 'Document Management/doc_upload.html', {
        'employees': employees,
        'is_hr_admin': is_hr_or_admin(request.user),
    })


@login_required
def doc_edit(request, doc_id):
    doc = get_object_or_404(EmployeeDocument, id=doc_id)
    if not is_hr_or_admin(request.user) and doc.employee != request.user:
        messages.error(request, 'Access denied.')
        return redirect('doc_list')

    if request.method == 'POST':
        doc.title = request.POST.get('title', doc.title)
        doc.description = request.POST.get('description', doc.description)
        doc.doc_type = request.POST.get('doc_type', doc.doc_type)
        if request.FILES.get('document_file'):
            doc.file = request.FILES['document_file']
        if is_hr_or_admin(request.user):
            doc.is_verified = request.POST.get('is_verified') == 'on'
            if doc.is_verified:
                doc.verified_by = request.user
        doc.save()
        messages.success(request, 'Document updated.')
        return redirect('doc_list')

    return render(request, 'Document Management/doc_edit.html', {'document': doc, 'is_hr_admin': is_hr_or_admin(request.user)})


@login_required
def doc_delete(request, doc_id):
    doc = get_object_or_404(EmployeeDocument, id=doc_id)
    if not is_hr_or_admin(request.user) and doc.employee != request.user:
        messages.error(request, 'Access denied.')
        return redirect('doc_list')
    if request.method == 'POST':
        doc.file.delete(save=False)
        doc.delete()
        messages.success(request, 'Document deleted.')
        return redirect('doc_list')
    return render(request, 'Document Management/doc_delete.html', {'document': doc})


@login_required
def doc_download(request, doc_id):
    doc = get_object_or_404(EmployeeDocument, id=doc_id)
    if not is_hr_or_admin(request.user) and doc.employee != request.user:
        raise Http404
    return FileResponse(doc.file.open('rb'), as_attachment=True, filename=doc.file.name.split('/')[-1])
