from django.contrib.auth.decorators import login_required

from .exports import dispatch_export
from .models import AttendanceRecord, Complaint, LeaveApplication, JobApplication, InterviewSchedule
from .permissions import is_hr_or_admin


@login_required
def export_leave(request):
    fmt = request.GET.get('format', 'csv')
    if is_hr_or_admin(request.user):
        apps = LeaveApplication.objects.select_related('employee').all()
    else:
        apps = LeaveApplication.objects.filter(employee=request.user)
    headers = ['Application No', 'Employee', 'Department', 'Type', 'From', 'To', 'Days', 'Status', 'Applied On']
    rows = [
        (
            a.application_no,
            a.employee.get_full_name() or a.employee.username,
            a.department,
            a.get_leave_type_display(),
            a.from_date,
            a.to_date,
            a.num_days,
            a.get_status_display(),
            a.applied_on.strftime('%Y-%m-%d'),
        )
        for a in apps
    ]
    return dispatch_export(fmt, 'leave_report', 'Leave Applications Report', headers, rows)


@login_required
def export_attendance(request):
    fmt = request.GET.get('format', 'csv')
    month = request.GET.get('month')
    year = request.GET.get('year')
    if is_hr_or_admin(request.user) and request.GET.get('all') == '1':
        records = AttendanceRecord.objects.select_related('employee').all()
    else:
        records = AttendanceRecord.objects.filter(employee=request.user)
    if month and year:
        records = records.filter(date__month=int(month), date__year=int(year))
    headers = ['Employee', 'Date', 'Check In', 'Check Out', 'Status', 'Location', 'Hours']
    rows = [
        (
            r.employee.get_full_name() or r.employee.username,
            r.date,
            r.check_in or '',
            r.check_out or '',
            r.get_status_display(),
            r.get_location_display(),
            r.hours_worked or '',
        )
        for r in records
    ]
    return dispatch_export(fmt, 'attendance_report', 'Attendance Report', headers, rows)


@login_required
def export_complaints(request):
    if not is_hr_or_admin(request.user):
        from django.shortcuts import redirect
        return redirect('dashboard')
    fmt = request.GET.get('format', 'csv')
    complaints = Complaint.objects.select_related('employee').all()
    headers = ['Ticket', 'Employee', 'Department', 'Category', 'Priority', 'Subject', 'Status', 'Created']
    rows = [
        (
            c.ticket_no,
            c.employee.get_full_name() or c.employee.username,
            c.department,
            c.get_category_display(),
            c.get_priority_display(),
            c.subject,
            c.get_status_display(),
            c.created_at.strftime('%Y-%m-%d'),
        )
        for c in complaints
    ]
    return dispatch_export(fmt, 'complaints_report', 'Complaints Report', headers, rows)


@login_required
def export_recruitment(request):
    if not is_hr_or_admin(request.user):
        from django.shortcuts import redirect
        return redirect('dashboard')
    fmt = request.GET.get('format', 'csv')
    export_type = request.GET.get('type', 'applications')
    if export_type == 'interviews':
        items = InterviewSchedule.objects.select_related('application').all()
        headers = ['Candidate', 'Round', 'Date', 'Time', 'Mode', 'Status', 'Interviewers']
        rows = [
            (
                i.application.candidate_name,
                i.get_round_display(),
                i.interview_date,
                i.interview_time,
                i.get_mode_display(),
                i.get_status_display(),
                i.interviewers,
            )
            for i in items
        ]
        return dispatch_export(fmt, 'interview_schedule', 'Interview Schedule', headers, rows)
    items = JobApplication.objects.select_related('job').all()
    headers = ['App No', 'Candidate', 'Email', 'Job', 'Status', 'Experience', 'Applied On']
    rows = [
        (
            a.app_no,
            a.candidate_name,
            a.candidate_email,
            a.job.title,
            a.get_status_display(),
            a.experience,
            a.applied_on.strftime('%Y-%m-%d'),
        )
        for a in items
    ]
    return dispatch_export(fmt, 'recruitment_report', 'Recruitment Report', headers, rows)


@login_required
def export_announcements(request):
    if not is_hr_or_admin(request.user):
        from django.shortcuts import redirect
        return redirect('dashboard')
    from .models import PolicyAnnouncement
    fmt = request.GET.get('format', 'csv')
    items = PolicyAnnouncement.objects.all()
    headers = ['Title', 'Priority', 'Status', 'Audience', 'Views', 'Published', 'Created']
    rows = [
        (
            a.title,
            a.get_priority_display(),
            a.get_status_display(),
            a.target_audience,
            a.views_count,
            a.published_at.strftime('%Y-%m-%d') if a.published_at else '',
            a.created_at.strftime('%Y-%m-%d'),
        )
        for a in items
    ]
    return dispatch_export(fmt, 'announcements_report', 'Announcements Report', headers, rows)
