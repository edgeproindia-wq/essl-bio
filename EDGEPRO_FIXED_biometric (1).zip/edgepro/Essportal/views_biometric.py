"""
views_biometric.py
────────────────────
API endpoint(s) for the biometric integration.

The office-PC sync agent (see biometric_agent/sync_agent.py) is the only
caller of this endpoint. It never talks to the device from Django/PythonAnywhere
directly — PythonAnywhere cannot reach a device sitting inside the office LAN.

Security:
  - Requires header 'X-Biometric-Api-Key' matching settings.BIOMETRIC_API_KEY.
  - CSRF-exempt because this is a machine-to-machine API, not a browser form
    (it is still protected by the API key, and should only ever be called
    over HTTPS in production).
  - Rejects with 401 immediately on a bad/missing key, does not leak details.
"""
import json
import logging

from django.conf import settings
from django.http import JsonResponse
from django.utils import timezone as tz
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from django.contrib.auth.decorators import login_required

from . import biometric_service
from .models import BiometricDevice, BiometricSyncLog, RawBiometricLog
from .permissions import hr_admin_required

logger = logging.getLogger('biometric')


def _check_api_key(request):
    expected = getattr(settings, 'BIOMETRIC_API_KEY', None)
    provided = request.headers.get('X-Biometric-Api-Key')
    return bool(expected) and provided == expected


@csrf_exempt
@require_POST
def biometric_sync_endpoint(request):
    """
    POST body:
    {
        "device_ip": "192.168.1.39",
        "device_name": "Hosur Main Gate",     (optional, used only on first-ever call for this IP)
        "punches": [
            {"user_id": "74", "timestamp": "2026-07-20T09:14:32", "punch_type": "0"},
            ...
        ]
    }
    """
    if not _check_api_key(request):
        logger.warning("Rejected biometric sync call: bad/missing API key from %s", request.META.get('REMOTE_ADDR'))
        return JsonResponse({'error': 'Unauthorized'}, status=401)

    try:
        payload = json.loads(request.body.decode('utf-8'))
    except (ValueError, UnicodeDecodeError):
        return JsonResponse({'error': 'Invalid JSON body'}, status=400)

    device_ip = payload.get('device_ip')
    punches = payload.get('punches', [])
    if not device_ip:
        return JsonResponse({'error': 'device_ip is required'}, status=400)
    if not isinstance(punches, list):
        return JsonResponse({'error': 'punches must be a list'}, status=400)

    device, _ = BiometricDevice.objects.get_or_create(
        ip_address=device_ip,
        defaults={'name': payload.get('device_name') or f'Device {device_ip}'},
    )

    sync_log = BiometricSyncLog.objects.create(device=device, status='running')

    try:
        summary = biometric_service.ingest_punches(device, punches, sync_log=sync_log)
        sync_log.status = 'success' if summary['errors'] == 0 else 'partial'
        sync_log.finished_at = tz.now()
        sync_log.save(update_fields=['status', 'finished_at'])

        device.last_sync_at = tz.now()
        device.last_sync_status = sync_log.status
        device.save(update_fields=['last_sync_at', 'last_sync_status'])

        return JsonResponse({'status': sync_log.status, **summary})

    except Exception as exc:  # noqa: BLE001
        logger.exception("Biometric sync batch failed for device %s", device_ip)
        sync_log.status = 'failed'
        sync_log.error_message = str(exc)
        sync_log.finished_at = tz.now()
        sync_log.save(update_fields=['status', 'error_message', 'finished_at'])

        device.last_sync_status = 'failed'
        device.save(update_fields=['last_sync_status'])

        return JsonResponse({'error': 'Internal processing error'}, status=500)


@login_required
@hr_admin_required
def biometric_dashboard(request):
    """Simple HR-facing troubleshooting view: recent syncs + unmatched punches."""
    devices = BiometricDevice.objects.all().order_by('name')
    recent_syncs = BiometricSyncLog.objects.select_related('device').all()[:20]
    unmatched = RawBiometricLog.objects.filter(matched=False).order_by('-received_at')[:50]
    return JsonResponse({
        'devices': [
            {
                'name': d.name, 'ip': d.ip_address, 'active': d.is_active,
                'last_sync_at': d.last_sync_at.isoformat() if d.last_sync_at else None,
                'last_sync_status': d.last_sync_status,
            } for d in devices
        ],
        'recent_syncs': [
            {
                'device': s.device.name if s.device else None,
                'started_at': s.started_at.isoformat(),
                'status': s.status,
                'received': s.records_received, 'matched': s.records_matched,
                'unmatched': s.records_unmatched, 'duplicate': s.records_duplicate,
            } for s in recent_syncs
        ],
        'unmatched_punches': [
            {'device_user_id': u.device_user_id, 'punch_time': u.punch_time.isoformat(), 'error': u.error_message}
            for u in unmatched
        ],
    })
