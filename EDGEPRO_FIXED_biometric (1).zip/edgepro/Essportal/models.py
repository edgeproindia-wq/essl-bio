from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone


# ─── Announcements ───────────────────────────────────────────────────────────

class PolicyCategory(models.Model):
    name = models.CharField(max_length=100)
    slug = models.SlugField(unique=True)
    color = models.CharField(max_length=7, default='#3B82F6')

    def __str__(self):
        return self.name

    class Meta:
        verbose_name_plural = "Policy Categories"


class PolicyAnnouncement(models.Model):
    STATUS_CHOICES = [('draft','Draft'),('published','Published'),('archived','Archived')]
    PRIORITY_CHOICES = [('low','Low'),('medium','Medium'),('high','High'),('urgent','Urgent')]

    title = models.CharField(max_length=255)
    slug = models.SlugField(unique=True)
    category = models.ForeignKey(PolicyCategory, on_delete=models.SET_NULL, null=True, blank=True, related_name='announcements')
    summary = models.TextField(max_length=500, blank=True)
    content = models.TextField()
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default='medium')
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='draft')
    target_audience = models.CharField(max_length=50, default='All Employees')
    effective_date = models.DateField(null=True, blank=True)
    expiry_date = models.DateField(null=True, blank=True)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='created_announcements')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    published_at = models.DateTimeField(null=True, blank=True)
    views_count = models.PositiveIntegerField(default=0)
    is_pinned = models.BooleanField(default=False)

    def __str__(self):
        return self.title

    def publish(self):
        self.status = 'published'
        self.published_at = timezone.now()
        self.save()

    class Meta:
        ordering = ['-is_pinned', '-published_at', '-created_at']


class AnnouncementAttachment(models.Model):
    announcement = models.ForeignKey(PolicyAnnouncement, on_delete=models.CASCADE, related_name='attachments')
    file = models.FileField(upload_to='announcements/attachments/')
    filename = models.CharField(max_length=255)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.filename


# ─── Attendance ───────────────────────────────────────────────────────────────

class AttendanceRecord(models.Model):
    STATUS_CHOICES = [('present','Present'),('absent','Absent'),('late','Late'),('half_day','Half Day'),('work_off','Work Off')]
    LOCATION_CHOICES = [('office','Main Office'),('wfh','Work From Home'),('client','Client Site'),('branch','Branch Office')]

    employee = models.ForeignKey(User, on_delete=models.CASCADE, related_name='attendance_records')
    date = models.DateField()
    check_in = models.TimeField(null=True, blank=True)
    check_out = models.TimeField(null=True, blank=True)
    location = models.CharField(max_length=20, choices=LOCATION_CHOICES, default='office')
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='present')
    note = models.TextField(blank=True)
    hours_worked = models.DecimalField(max_digits=4, decimal_places=2, null=True, blank=True)
    work_summary = models.TextField(blank=True)

    class Meta:
        unique_together = ('employee', 'date')
        ordering = ['-date']

    def __str__(self):
        return f"{self.employee.username} - {self.date}"


# ─── Biometric Attendance Integration ──────────────────────────────────────────

class BiometricDevice(models.Model):
    """
    Registry of eSSL biometric devices. Supports multiple devices/locations —
    every raw punch and sync log references the device it came from.
    """
    name = models.CharField(max_length=100, help_text="e.g. 'Hosur Main Gate'")
    ip_address = models.GenericIPAddressField()
    port = models.PositiveIntegerField(default=4370)
    model_name = models.CharField(max_length=100, blank=True)
    location = models.CharField(max_length=100, blank=True)
    is_active = models.BooleanField(default=True)
    last_sync_at = models.DateTimeField(null=True, blank=True)
    last_sync_status = models.CharField(max_length=20, default='never', choices=[
        ('never', 'Never Synced'), ('success', 'Success'), ('failed', 'Failed'), ('partial', 'Partial'),
    ])
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} ({self.ip_address}:{self.port})"


class RawBiometricLog(models.Model):
    """
    Every original punch received from a biometric device, stored exactly as
    received, before any processing. This is the permanent audit trail —
    processed AttendanceRecord entries can always be reconstructed/verified
    against this table.
    """
    PUNCH_TYPE_CHOICES = [
        ('0', 'Check In'), ('1', 'Check Out'),
        ('2', 'Break Out'), ('3', 'Break In'),
        ('4', 'OT In'), ('5', 'OT Out'),
        ('unknown', 'Unknown'),
    ]

    device = models.ForeignKey(BiometricDevice, on_delete=models.SET_NULL, null=True, related_name='raw_logs')
    device_user_id = models.CharField(max_length=30, db_index=True, help_text="Raw User ID as sent by the device")
    punch_time = models.DateTimeField(db_index=True)
    punch_type = models.CharField(max_length=10, choices=PUNCH_TYPE_CHOICES, default='unknown')
    raw_payload = models.TextField(blank=True, help_text="Full raw record from the device, for debugging")

    # Processing / linkage status
    employee = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='biometric_logs')
    matched = models.BooleanField(default=False, help_text="True once device_user_id was successfully matched to an employee")
    processed = models.BooleanField(default=False, help_text="True once this punch has been applied to AttendanceRecord")
    processed_at = models.DateTimeField(null=True, blank=True)
    attendance_record = models.ForeignKey(AttendanceRecord, on_delete=models.SET_NULL, null=True, blank=True, related_name='biometric_logs')
    error_message = models.CharField(max_length=255, blank=True)

    received_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        # Hard duplicate guard: the same device can never report the exact same
        # user+timestamp+type twice — this is the DB-level dedup safety net,
        # on top of the application-level check in biometric_service.py
        unique_together = ('device', 'device_user_id', 'punch_time', 'punch_type')
        indexes = [
            models.Index(fields=['device_user_id', 'punch_time']),
            models.Index(fields=['processed']),
        ]
        ordering = ['-punch_time']

    def __str__(self):
        return f"Device#{self.device_id} User#{self.device_user_id} @ {self.punch_time}"


class BiometricSyncLog(models.Model):
    """
    One row per sync run (each time the agent polls a device), for auditing
    and troubleshooting — how many punches came in, how many matched, errors.
    """
    device = models.ForeignKey(BiometricDevice, on_delete=models.SET_NULL, null=True, related_name='sync_logs')
    started_at = models.DateTimeField(auto_now_add=True)
    finished_at = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=20, default='running', choices=[
        ('running', 'Running'), ('success', 'Success'), ('failed', 'Failed'), ('partial', 'Partial'),
    ])
    records_received = models.PositiveIntegerField(default=0)
    records_matched = models.PositiveIntegerField(default=0)
    records_unmatched = models.PositiveIntegerField(default=0)
    records_duplicate = models.PositiveIntegerField(default=0)
    error_message = models.TextField(blank=True)

    class Meta:
        ordering = ['-started_at']

    def __str__(self):
        return f"Sync {self.device} @ {self.started_at:%Y-%m-%d %H:%M} - {self.status}"


class LateLoginRequest(models.Model):
    STATUS_CHOICES = [('pending','Pending'),('approved','Approved'),('rejected','Rejected')]
    REASON_CHOICES = [
        ('traffic','Traffic / Transportation delay'),
        ('medical','Medical appointment'),
        ('family','Family emergency'),
        ('power','Power / Internet outage'),
        ('other','Other'),
    ]

    employee = models.ForeignKey(User, on_delete=models.CASCADE, related_name='late_login_requests')
    date = models.DateField()
    actual_checkin = models.TimeField()
    reason = models.CharField(max_length=20, choices=REASON_CHOICES, default='other')
    details = models.TextField(blank=True)
    manager = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='late_login_approvals')
    supporting_doc = models.FileField(upload_to='late_login_docs/', null=True, blank=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.employee.username} - {self.date} ({self.status})"


# ─── Leave Management ─────────────────────────────────────────────────────────

class LeaveBalance(models.Model):
    employee = models.OneToOneField(User, on_delete=models.CASCADE, related_name='leave_balance')
    casual_total = models.IntegerField(default=12)
    casual_used = models.IntegerField(default=0)
    sick_total = models.IntegerField(default=12)
    sick_used = models.IntegerField(default=0)
    earned_total = models.IntegerField(default=15)
    earned_used = models.IntegerField(default=0)
    comp_off = models.DecimalField(max_digits=4, decimal_places=1, default=0)
    cash_total = models.IntegerField(default=6)
    cash_used = models.IntegerField(default=0)

    def __str__(self):
        return f"{self.employee.username} - Leave Balance"


class LeaveApplication(models.Model):
    TYPE_CHOICES = [
        ('casual','Casual Leave'),('sick','Sick Leave'),('earned','Earned Leave'),
        ('emergency','Emergency Leave'),('maternity','Maternity/Paternity Leave'),('comp_off','Compensatory Off'),
        ('cash','Cash Leave'),
    ]
    STATUS_CHOICES = [('pending','Pending'),('approved','Approved'),('rejected','Rejected'),('cancelled','Cancelled')]
    STAGE_CHOICES = [('tl','Awaiting Team Leader'),('hr','Awaiting HR'),('done','Completed')]
    SESSION_CHOICES = [('full','Full Day'),('first','First Half'),('second','Second Half')]

    application_no = models.CharField(max_length=20, unique=True, blank=True)
    employee = models.ForeignKey(User, on_delete=models.CASCADE, related_name='leave_applications')
    department = models.CharField(max_length=100, blank=True, help_text="Manually entered department, e.g. Engineering")
    leave_type = models.CharField(max_length=20, choices=TYPE_CHOICES)
    from_date = models.DateField()
    to_date = models.DateField()
    session = models.CharField(max_length=10, choices=SESSION_CHOICES, default='full')
    num_days = models.DecimalField(max_digits=4, decimal_places=1, default=1)
    reason = models.TextField()
    approver = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='leave_approvals')
    handover_to = models.CharField(max_length=100, blank=True)
    contact_during_leave = models.CharField(max_length=20, blank=True)
    supporting_doc = models.FileField(upload_to='leave_docs/', null=True, blank=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    approval_stage = models.CharField(max_length=10, choices=STAGE_CHOICES, default='tl')
    tl_approver = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='tl_leave_approvals')
    tl_approved_at = models.DateTimeField(null=True, blank=True)
    rejection_reason = models.TextField(blank=True)
    applied_on = models.DateTimeField(auto_now_add=True)
    actioned_on = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['-applied_on']

    def save(self, *args, **kwargs):
        if not self.application_no:
            import random
            self.application_no = f"LV-{timezone.now().year}-{random.randint(100,999)}"
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.application_no} - {self.employee.username}"


class LeaveDraft(models.Model):
    """A saved-but-not-submitted leave application, so users don't lose in-progress work."""
    employee = models.ForeignKey(User, on_delete=models.CASCADE, related_name='leave_drafts')
    department = models.CharField(max_length=100, blank=True)
    leave_type = models.CharField(max_length=20, blank=True)
    from_date = models.DateField(null=True, blank=True)
    to_date = models.DateField(null=True, blank=True)
    session = models.CharField(max_length=10, blank=True, default='full')
    num_days = models.DecimalField(max_digits=4, decimal_places=1, null=True, blank=True)
    reason = models.TextField(blank=True)
    handover_to = models.CharField(max_length=100, blank=True)
    contact_during_leave = models.CharField(max_length=20, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-updated_at']

    def __str__(self):
        return f"Draft ({self.employee.username}) - {self.updated_at:%Y-%m-%d %H:%M}"


# ─── Payroll ──────────────────────────────────────────────────────────────────

class EmployeeSalary(models.Model):
    employee = models.ForeignKey(User, on_delete=models.CASCADE, related_name='salary_records')
    month = models.CharField(max_length=20)
    year = models.IntegerField()
    basic = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    hra = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    special_allowance = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    gross_salary = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    pf_deduction = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    professional_tax = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    tds = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total_deductions = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    net_pay = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    credited_on = models.DateField(null=True, blank=True)
    is_credited = models.BooleanField(default=False)

    class Meta:
        ordering = ['-year', '-month']
        unique_together = ('employee', 'month', 'year')

    def __str__(self):
        return f"{self.employee.username} - {self.month} {self.year}"


class BonusRecord(models.Model):
    employee = models.ForeignKey(User, on_delete=models.CASCADE, related_name='bonus_records')
    bonus_type = models.CharField(max_length=50)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.TextField(blank=True)
    awarded_on = models.DateField()
    tax_deducted = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    class Meta:
        ordering = ['-awarded_on']

    def __str__(self):
        return f"{self.employee.username} - {self.bonus_type}"


# ─── Complaint Management ─────────────────────────────────────────────────────

class Complaint(models.Model):
    CATEGORY_CHOICES = [
        ('payroll','Payroll Issue'),('harassment','Workplace Harassment'),('facilities','Facilities'),
        ('hr_policy','HR Policy'),('it','IT Issue'),('other','Other'),
    ]
    PRIORITY_CHOICES = [('low','Low'),('medium','Medium'),('high','High'),('urgent','Urgent')]
    STATUS_CHOICES = [('open','Open'),('in_progress','In Progress'),('resolved','Resolved'),('closed','Closed')]

    ticket_no = models.CharField(max_length=20, unique=True, blank=True)
    employee = models.ForeignKey(User, on_delete=models.CASCADE, related_name='complaints')
    department = models.CharField(max_length=100, blank=True, help_text="Manually entered department, e.g. Engineering")
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES)
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default='medium')
    subject = models.CharField(max_length=200)
    description = models.TextField()
    is_anonymous = models.BooleanField(default=False)
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='open')
    assigned_to = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='assigned_complaints')
    resolution_note = models.TextField(blank=True)
    resolved_on = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def save(self, *args, **kwargs):
        if not self.ticket_no:
            import random
            self.ticket_no = f"CMP-{timezone.now().year}-{random.randint(100,999)}"
        super().save(*args, **kwargs)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.ticket_no} - {self.subject}"


# ─── Recruitment ──────────────────────────────────────────────────────────────

class JobPosting(models.Model):
    STATUS_CHOICES = [('open','Open'),('on_hold','On Hold'),('closed','Closed')]

    title = models.CharField(max_length=100)
    department = models.CharField(max_length=50)
    location = models.CharField(max_length=100)
    employment_type = models.CharField(max_length=30, default='Full Time')
    description = models.TextField()
    skills = models.CharField(max_length=300, blank=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='open')
    posted_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='job_postings')
    posted_on = models.DateField(auto_now_add=True)
    closing_date = models.DateField(null=True, blank=True)

    class Meta:
        ordering = ['-posted_on']

    def __str__(self):
        return self.title


class JobApplication(models.Model):
    STATUS_CHOICES = [
        ('submitted','Submitted'),('screening','Screening'),('shortlisted','Shortlisted'),
        ('interview','Interview'),('selected','Selected'),('rejected','Rejected'),
    ]
    APP_TYPE_CHOICES = [('self','Self Application'),('referral','Employee Referral')]

    app_no = models.CharField(max_length=20, unique=True, blank=True)
    job = models.ForeignKey(JobPosting, on_delete=models.CASCADE, related_name='applications')
    referred_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='referrals')
    application_type = models.CharField(max_length=10, choices=APP_TYPE_CHOICES, default='self')
    candidate_name = models.CharField(max_length=100)
    candidate_email = models.EmailField()
    candidate_phone = models.CharField(max_length=20)
    experience = models.CharField(max_length=30)
    current_ctc = models.CharField(max_length=30, blank=True)
    expected_ctc = models.CharField(max_length=30, blank=True)
    notice_period = models.CharField(max_length=30, default='30 days')
    resume = models.FileField(upload_to='resumes/', null=True, blank=True)
    cover_letter = models.TextField(blank=True)
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='submitted')
    applied_on = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if not self.app_no:
            import random
            self.app_no = f"APP-{timezone.now().year}-{random.randint(100,999)}"
        super().save(*args, **kwargs)

    class Meta:
        ordering = ['-applied_on']

    def __str__(self):
        return f"{self.app_no} - {self.candidate_name}"


class InterviewSchedule(models.Model):
    ROUND_CHOICES = [
        ('hr_screen','Round 1 – HR Screening'),('technical','Round 2 – Technical'),
        ('managerial','Round 3 – Managerial'),('final','Final – HR Discussion'),
    ]
    MODE_CHOICES = [('in_person','In Person'),('video','Video Call'),('phone','Telephonic')]
    STATUS_CHOICES = [('scheduled','Scheduled'),('confirmed','Confirmed'),('completed','Completed'),('cancelled','Cancelled')]

    application = models.ForeignKey(JobApplication, on_delete=models.CASCADE, related_name='interviews')
    round = models.CharField(max_length=20, choices=ROUND_CHOICES)
    interview_date = models.DateField()
    interview_time = models.TimeField()
    mode = models.CharField(max_length=15, choices=MODE_CHOICES, default='in_person')
    interviewers = models.CharField(max_length=300)
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='scheduled')
    notes = models.TextField(blank=True)
    scheduled_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='scheduled_interviews')
    rescheduled_from = models.ForeignKey(
        'self', on_delete=models.SET_NULL, null=True, blank=True, related_name='reschedules'
    )
    email_sent = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['interview_date', 'interview_time']

    def __str__(self):
        return f"{self.application.candidate_name} - {self.round}"


# ─── Workflow ─────────────────────────────────────────────────────────────────

class WorkflowRequest(models.Model):
    TYPE_CHOICES = [('leave','Leave'),('expense','Expense'),('wfh','Work From Home'),('overtime','Overtime'),('late_login','Late Login'),('other','Other')]
    STATUS_CHOICES = [('pending','Pending'),('approved','Approved'),('rejected','Rejected')]

    request_type = models.CharField(max_length=15, choices=TYPE_CHOICES)
    employee = models.ForeignKey(User, on_delete=models.CASCADE, related_name='workflow_requests')
    description = models.TextField()
    amount = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    from_date = models.DateField(null=True, blank=True)
    to_date = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    approver = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='workflow_decisions')
    rejection_reason = models.CharField(max_length=200, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    decided_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.request_type} - {self.employee.username}"


# ─── Work Tracking ────────────────────────────────────────────────────────────

class DailyWorkUpdate(models.Model):
    employee = models.ForeignKey(User, on_delete=models.CASCADE, related_name='daily_updates')
    date = models.DateField()
    hours_worked = models.DecimalField(max_digits=4, decimal_places=2)
    tasks_completed = models.TextField()
    tasks_in_progress = models.TextField(blank=True)
    planned_tomorrow = models.TextField(blank=True)
    submitted_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('employee', 'date')
        ordering = ['-date']

    def __str__(self):
        return f"{self.employee.username} - {self.date}"


class Project(models.Model):
    STATUS_CHOICES = [('on_track','On Track'),('at_risk','At Risk'),('delayed','Delayed'),('completed','Completed')]

    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    manager = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='managed_projects')
    team_members = models.ManyToManyField(User, related_name='project_members', blank=True)
    start_date = models.DateField()
    due_date = models.DateField()
    progress = models.IntegerField(default=0)
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='on_track')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.name


class Task(models.Model):
    PRIORITY_CHOICES = [('low','Low'),('medium','Medium'),('high','High'),('critical','Critical')]
    STATUS_CHOICES = [('todo','To Do'),('in_progress','In Progress'),('completed','Completed'),('blocked','Blocked')]

    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    project = models.ForeignKey(Project, on_delete=models.SET_NULL, null=True, blank=True, related_name='tasks')
    assigned_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='assigned_tasks')
    assigned_to = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='my_tasks')
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default='medium')
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default='todo')
    start_date = models.DateField(null=True, blank=True)
    due_date = models.DateField(null=True, blank=True)
    estimated_hours = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.title


class TimeEntry(models.Model):
    employee = models.ForeignKey(User, on_delete=models.CASCADE, related_name='time_entries')
    project = models.ForeignKey(Project, on_delete=models.SET_NULL, null=True, blank=True, related_name='time_entries')
    task_description = models.CharField(max_length=300)
    date = models.DateField()
    start_time = models.TimeField()
    end_time = models.TimeField()
    hours = models.DecimalField(max_digits=4, decimal_places=2)
    is_billable = models.BooleanField(default=True)
    location = models.CharField(max_length=100, blank=True, default='')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-date', '-start_time']

    def __str__(self):
        return f"{self.employee.username} - {self.date} - {self.hours}h"


# ─── Employee Profile ─────────────────────────────────────────────────────────

class EmployeeProfile(models.Model):
    GENDER_CHOICES = [('male','Male'),('female','Female'),('other','Other')]
    BLOOD_CHOICES = [('A+','A+'),('A-','A-'),('B+','B+'),('B-','B-'),('O+','O+'),('O-','O-'),('AB+','AB+'),('AB-','AB-')]
    EMP_TYPE_CHOICES = [('full_time','Full Time'),('part_time','Part Time'),('contract','Contract'),('intern','Intern')]

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    employee_id = models.CharField(max_length=20, unique=True)
    date_of_birth = models.DateField(null=True, blank=True)
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES, blank=True)
    blood_group = models.CharField(max_length=5, choices=BLOOD_CHOICES, blank=True)
    phone = models.CharField(max_length=20, blank=True)
    address = models.TextField(blank=True)
    emergency_contact_name = models.CharField(max_length=100, blank=True)
    emergency_contact_phone = models.CharField(max_length=20, blank=True)
    designation = models.CharField(max_length=100, blank=True)
    department = models.CharField(max_length=100, blank=True)
    reporting_manager = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='direct_reports')
    date_of_joining = models.DateField(null=True, blank=True)
    employment_type = models.CharField(max_length=15, choices=EMP_TYPE_CHOICES, default='full_time')
    work_location = models.CharField(max_length=100, blank=True)
    aadhar_verified = models.BooleanField(default=False)
    pan_verified = models.BooleanField(default=False)
    offer_letter_uploaded = models.BooleanField(default=False)
    education_cert_uploaded = models.BooleanField(default=False)
    experience_letter_uploaded = models.BooleanField(default=False)

    # ── Biometric device mapping ──
    # The numeric/alphanumeric "User ID" assigned to this employee on the eSSL
    # biometric device. This is DIFFERENT from employee_id (Emp Code) above —
    # the device has its own ID system and every punch it sends references this.
    biometric_user_id = models.CharField(
        max_length=30, unique=True, null=True, blank=True,
        help_text="User ID assigned to this employee on the eSSL biometric device (not the Emp Code)."
    )

    REGISTRATION_STATUS_CHOICES = [
        ('pending', 'Pending Approval'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]
    registration_status = models.CharField(
        max_length=10,
        choices=REGISTRATION_STATUS_CHOICES,
        default='approved',
    )
    registered_at = models.DateTimeField(auto_now_add=True, null=True)
    approved_at = models.DateTimeField(null=True, blank=True)
    approved_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='approved_employees'
    )

    def __str__(self):
        return f"{self.user.get_full_name()} ({self.employee_id})"


# ─── Document Management ───────────────────────────────────────────────────────

class EmployeeDocument(models.Model):
    DOC_TYPE_CHOICES = [
        ('aadhar', 'Aadhar Card'),
        ('pan', 'PAN Card'),
        ('offer_letter', 'Offer Letter'),
        ('education_cert', 'Education Certificate'),
        ('experience_letter', 'Experience Letter'),
        ('resume', 'Resume'),
        ('other', 'Other'),
    ]

    employee = models.ForeignKey(User, on_delete=models.CASCADE, related_name='documents')
    doc_type = models.CharField(max_length=30, choices=DOC_TYPE_CHOICES, default='other')
    title = models.CharField(max_length=200)
    file = models.FileField(upload_to='documents/%Y/%m/')
    description = models.TextField(blank=True)
    uploaded_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, related_name='uploaded_documents'
    )
    is_verified = models.BooleanField(default=False)
    verified_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, blank=True, related_name='verified_documents'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.title} ({self.employee.username})"


# ─── Notifications ─────────────────────────────────────────────────────────────

class Notification(models.Model):
    CATEGORY_CHOICES = [
        ('general', 'General'),
        ('announcement', 'Announcement'),
        ('leave', 'Leave'),
        ('recruitment', 'Recruitment'),
        ('workflow', 'Workflow'),
        ('document', 'Document'),
        ('attendance', 'Attendance'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notifications')
    title = models.CharField(max_length=200)
    message = models.TextField()
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, default='general')
    link = models.CharField(max_length=500, blank=True)
    is_read = models.BooleanField(default=False)
    email_sent = models.BooleanField(default=False)
    push_sent = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.user.username}: {self.title}"


class NotificationPreference(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='notification_prefs')
    email_enabled = models.BooleanField(default=True)
    push_enabled = models.BooleanField(default=True)
    sms_enabled = models.BooleanField(default=False)
    weekly_digest = models.BooleanField(default=True)
    push_token = models.CharField(max_length=500, blank=True)

    def __str__(self):
        return f"Prefs: {self.user.username}"
