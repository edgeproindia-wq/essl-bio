from django.contrib import admin
from .models import (
    PolicyCategory, PolicyAnnouncement, AnnouncementAttachment,
    AttendanceRecord, LateLoginRequest,
    LeaveBalance, LeaveApplication,
    EmployeeSalary, BonusRecord,
    Complaint,
    JobPosting, JobApplication, InterviewSchedule,
    WorkflowRequest,
    DailyWorkUpdate, Project, Task, TimeEntry,
    EmployeeProfile, EmployeeDocument,
    Notification, NotificationPreference,
    BiometricDevice, RawBiometricLog, BiometricSyncLog,
)

admin.site.register(PolicyCategory)
admin.site.register(PolicyAnnouncement)
admin.site.register(AnnouncementAttachment)
admin.site.register(AttendanceRecord)
admin.site.register(LateLoginRequest)
admin.site.register(LeaveBalance)
admin.site.register(EmployeeSalary)
admin.site.register(BonusRecord)
admin.site.register(JobPosting)
admin.site.register(JobApplication)
admin.site.register(InterviewSchedule)
admin.site.register(WorkflowRequest)
admin.site.register(DailyWorkUpdate)
admin.site.register(Project)
admin.site.register(Task)
admin.site.register(TimeEntry)
admin.site.register(EmployeeDocument)
admin.site.register(Notification)
admin.site.register(NotificationPreference)


@admin.register(LeaveApplication)
class LeaveApplicationAdmin(admin.ModelAdmin):
    list_display = ('application_no', 'employee', 'department', 'leave_type', 'from_date', 'to_date', 'status')
    list_filter = ('leave_type', 'status', 'department')
    search_fields = ('application_no', 'employee__username', 'department')


@admin.register(Complaint)
class ComplaintAdmin(admin.ModelAdmin):
    list_display = ('ticket_no', 'employee', 'department', 'category', 'priority', 'status', 'created_at')
    list_filter = ('category', 'priority', 'status', 'department')
    search_fields = ('ticket_no', 'employee__username', 'department', 'subject')


@admin.register(EmployeeProfile)
class EmployeeProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'employee_id', 'biometric_user_id', 'department', 'designation', 'registered_at')
    list_filter = ('department', 'employment_type')
    search_fields = ('user__username', 'user__first_name', 'user__last_name', 'employee_id', 'biometric_user_id')
    readonly_fields = ('registered_at',)


@admin.register(BiometricDevice)
class BiometricDeviceAdmin(admin.ModelAdmin):
    list_display = ('name', 'ip_address', 'port', 'is_active', 'last_sync_at', 'last_sync_status')
    list_filter = ('is_active', 'last_sync_status')
    search_fields = ('name', 'ip_address')


@admin.register(RawBiometricLog)
class RawBiometricLogAdmin(admin.ModelAdmin):
    list_display = ('device', 'device_user_id', 'punch_time', 'employee', 'matched', 'processed', 'received_at')
    list_filter = ('matched', 'processed', 'device')
    search_fields = ('device_user_id', 'employee__username', 'employee__first_name', 'employee__last_name')
    readonly_fields = ('received_at',)
    date_hierarchy = 'punch_time'


@admin.register(BiometricSyncLog)
class BiometricSyncLogAdmin(admin.ModelAdmin):
    list_display = ('device', 'started_at', 'status', 'records_received', 'records_matched',
                     'records_unmatched', 'records_duplicate')
    list_filter = ('status', 'device')
    readonly_fields = ('started_at', 'finished_at')
    date_hierarchy = 'started_at'

