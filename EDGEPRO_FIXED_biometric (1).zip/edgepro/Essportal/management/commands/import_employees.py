"""
Bulk-import employees from Book3.xlsx into User + EmployeeProfile + LeaveBalance.

Usage (run from the project root, same folder as manage.py):

    python manage.py import_employees
    python manage.py import_employees --dry-run
    python manage.py import_employees --file Book3.xlsx --status all
    python manage.py import_employees --status working

Excel columns expected (exact headers from Book3.xlsx):
    Emp Code | Name | Manager | Location | Dept | Team | Designation |
    Date of Joining | Status | Last Working day Date | Remarks
"""
import datetime
import os

import openpyxl
from django.contrib.auth.models import User
from django.core.management.base import BaseCommand
from django.utils import timezone

from Essportal.models import EmployeeProfile, LeaveBalance

DEFAULT_PASSWORD = "Edgepro@123"  # same default already used for the 141 live accounts


class Command(BaseCommand):
    help = "Bulk-create employee logins from Book3.xlsx"

    def add_arguments(self, parser):
        parser.add_argument(
            "--file", default="Book3.xlsx",
            help="Path to the Excel file (default: Book3.xlsx in project root)",
        )
        parser.add_argument(
            "--status", default="working", choices=["working", "all"],
            help="working = only import employees whose Status is 'working' (default). "
                 "all = import everyone, but mark non-working accounts inactive.",
        )
        parser.add_argument(
            "--dry-run", action="store_true",
            help="Show what would happen without creating anything.",
        )

    def handle(self, *args, **opts):
        path = opts["file"]
        dry_run = opts["dry_run"]
        status_filter = opts["status"]

        if not os.path.exists(path):
            self.stderr.write(self.style.ERROR(f"File not found: {path}"))
            self.stderr.write("Put Book3.xlsx in the same folder as manage.py, or pass --file <path>")
            return

        wb = openpyxl.load_workbook(path, data_only=True)
        sheet = wb.active

        created, skipped_existing, skipped_status, errors = 0, 0, 0, 0

        # pass 1: create users + profiles
        for row_num, row in enumerate(sheet.iter_rows(min_row=2, values_only=True), start=2):
            if row is None or row[0] is None:
                continue

            emp_code = str(row[0]).strip()
            name = str(row[1] or "").strip()
            manager = str(row[2] or "").strip()
            location = str(row[3] or "").strip()
            dept = str(row[4] or "").strip()
            team = str(row[5] or "").strip()
            designation = str(row[6] or "").strip()
            doj = row[7]
            status_raw = str(row[8] or "").strip()
            status = status_raw.lower()

            if not emp_code or not name:
                self.stdout.write(self.style.WARNING(f"Row {row_num}: missing Emp Code or Name, skipped"))
                errors += 1
                continue

            is_working = status == "working"
            if status_filter == "working" and not is_working:
                skipped_status += 1
                continue

            if User.objects.filter(username=emp_code).exists():
                skipped_existing += 1
                continue

            name_parts = name.split(" ", 1)
            first_name = name_parts[0]
            last_name = name_parts[1] if len(name_parts) > 1 else ""

            doj_date = None
            if isinstance(doj, (datetime.date, datetime.datetime)):
                doj_date = doj.date() if isinstance(doj, datetime.datetime) else doj

            if dry_run:
                self.stdout.write(f"[dry-run] would create {emp_code} - {name} ({status_raw or 'no status'})")
                created += 1
                continue

            user = User.objects.create_user(
                username=emp_code,
                password=DEFAULT_PASSWORD,
                first_name=first_name,
                last_name=last_name,
            )
            user.is_active = is_working
            user.save()

            EmployeeProfile.objects.get_or_create(
                user=user,
                defaults={
                    "employee_id": emp_code,
                    "department": dept or team,
                    "designation": designation,
                    "work_location": location,
                    "date_of_joining": doj_date,
                    "registration_status": "approved",
                    "approved_at": timezone.now(),
                },
            )
            LeaveBalance.objects.get_or_create(employee=user)

            # stash the manager's name on the instance for pass 2 (not saved to DB)
            user._manager_name = manager
            created += 1

        # pass 2: best-effort link reporting_manager by matching full name
        if not dry_run:
            all_users = list(User.objects.select_related("profile").all())
            name_lookup = {u.get_full_name().strip().lower(): u for u in all_users if u.get_full_name().strip()}

            wb2 = openpyxl.load_workbook(path, data_only=True)
            sheet2 = wb2.active
            linked, unmatched_managers = 0, set()
            for row in sheet2.iter_rows(min_row=2, values_only=True):
                if row is None or row[0] is None:
                    continue
                emp_code = str(row[0]).strip()
                manager_name = str(row[2] or "").strip()
                if not manager_name or manager_name.upper() == "NA":
                    continue
                try:
                    employee_user = User.objects.get(username=emp_code)
                except User.DoesNotExist:
                    continue
                manager_user = name_lookup.get(manager_name.strip().lower())
                if manager_user and hasattr(employee_user, "profile"):
                    employee_user.profile.reporting_manager = manager_user
                    employee_user.profile.save(update_fields=["reporting_manager"])
                    linked += 1
                elif manager_user is None:
                    unmatched_managers.add(manager_name)

            self.stdout.write(self.style.SUCCESS(f"Linked {linked} employees to a reporting manager"))
            if unmatched_managers:
                self.stdout.write(self.style.WARNING(
                    f"Could not match {len(unmatched_managers)} manager name(s) to an employee account "
                    f"(left blank, fix manually): {', '.join(sorted(unmatched_managers))}"
                ))

        self.stdout.write(self.style.SUCCESS(
            f"\nDone. Created: {created}, already existed (skipped): {skipped_existing}, "
            f"skipped by status filter: {skipped_status}, bad rows: {errors}"
        ))
        if not dry_run and created:
            self.stdout.write(f"Login format -> Username: <Emp Code>   Password: {DEFAULT_PASSWORD}")
