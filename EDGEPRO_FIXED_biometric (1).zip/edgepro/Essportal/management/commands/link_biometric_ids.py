"""
Link eSSL biometric device User IDs to existing employees, by matching names.

This is the "Emp Code + Name" method: you already have every employee's
Emp Code and Name in the system (via import_employees.py). This command takes
the device's enrolled user list (Device User ID + Name) and matches each one
to the employee with the same name, then fills in
EmployeeProfile.biometric_user_id — no manual one-by-one linking needed.

Input file: a 2-column Excel sheet exported from the eSSL device/software,
or produced by biometric_agent/list_device_users.py:
    User ID | Name
    74      | Christopher Jeeva
    76      | Jinovin S
    77      | Vasanthakumar K

Usage (run from the project root, same folder as manage.py):

    python manage.py link_biometric_ids --file device_users.xlsx --dry-run
    python manage.py link_biometric_ids --file device_users.xlsx
"""
import os
import re

import openpyxl
from django.core.management.base import BaseCommand

from Essportal.models import EmployeeProfile


def normalize_name(name: str) -> str:
    """Lowercase, strip, collapse whitespace, drop punctuation — for forgiving matching."""
    name = (name or '').lower().strip()
    name = re.sub(r'[^a-z0-9\s]', '', name)
    name = re.sub(r'\s+', ' ', name)
    return name


class Command(BaseCommand):
    help = "Match device User IDs to employees by name and set EmployeeProfile.biometric_user_id"

    def add_arguments(self, parser):
        parser.add_argument(
            "--file", required=True,
            help="Path to the 2-column Excel export from the biometric device (User ID | Name)",
        )
        parser.add_argument(
            "--dry-run", action="store_true",
            help="Show the matches that WOULD be made, without saving anything.",
        )

    def handle(self, *args, **opts):
        path = opts["file"]
        dry_run = opts["dry_run"]

        if not os.path.exists(path):
            self.stderr.write(self.style.ERROR(f"File not found: {path}"))
            return

        wb = openpyxl.load_workbook(path, data_only=True)
        sheet = wb.active

        # Build a name -> EmployeeProfile lookup from the existing ESS data.
        profiles = list(EmployeeProfile.objects.select_related('user').all())
        name_lookup = {}
        for p in profiles:
            full_name = normalize_name(p.user.get_full_name())
            if full_name:
                name_lookup.setdefault(full_name, []).append(p)

        matched, already_set, ambiguous, unmatched = [], [], [], []

        for row_num, row in enumerate(sheet.iter_rows(min_row=2, values_only=True), start=2):
            if row is None or row[0] is None:
                continue
            device_user_id = str(row[0]).strip()
            device_name = str(row[1] or '').strip()
            if not device_user_id or not device_name:
                continue

            candidates = name_lookup.get(normalize_name(device_name), [])

            if len(candidates) == 0:
                unmatched.append((device_user_id, device_name))
            elif len(candidates) > 1:
                ambiguous.append((device_user_id, device_name, candidates))
            else:
                profile = candidates[0]
                if profile.biometric_user_id == device_user_id:
                    already_set.append((device_user_id, device_name))
                elif profile.biometric_user_id:
                    ambiguous.append((device_user_id, device_name, [profile]))
                    self.stdout.write(self.style.WARNING(
                        f"Row {row_num}: {profile.employee_id} ({device_name}) already has "
                        f"biometric_user_id={profile.biometric_user_id!r} — not overwriting. "
                        f"Fix manually if this needs to change."
                    ))
                else:
                    matched.append((device_user_id, device_name, profile))

        self.stdout.write(self.style.SUCCESS(f"\nMatched (new): {len(matched)}"))
        for device_user_id, device_name, profile in matched:
            self.stdout.write(f"  Device #{device_user_id:>6}  {device_name:<30} -> {profile.employee_id} ({profile.user.username})")

        if already_set:
            self.stdout.write(self.style.SUCCESS(f"\nAlready correctly linked: {len(already_set)}"))

        if ambiguous:
            self.stdout.write(self.style.WARNING(f"\nAmbiguous / conflicting (skipped, needs manual review): {len(ambiguous)}"))
            for device_user_id, device_name, candidates in ambiguous:
                names = ', '.join(f"{c.employee_id}" for c in candidates)
                self.stdout.write(f"  Device #{device_user_id:>6}  {device_name:<30} -> multiple/conflicting matches: {names}")

        if unmatched:
            self.stdout.write(self.style.ERROR(f"\nNo matching employee found: {len(unmatched)}"))
            for device_user_id, device_name in unmatched:
                self.stdout.write(f"  Device #{device_user_id:>6}  {device_name}")
            self.stdout.write(
                "  -> Check spelling differences between the device name and the ESS name, "
                "or these employees may not be in the ESS system yet."
            )

        if dry_run:
            self.stdout.write(self.style.WARNING("\n[DRY RUN] Nothing was saved. Re-run without --dry-run to apply."))
            return

        for device_user_id, device_name, profile in matched:
            profile.biometric_user_id = device_user_id
            profile.save(update_fields=['biometric_user_id'])

        self.stdout.write(self.style.SUCCESS(f"\nSaved {len(matched)} new links."))
