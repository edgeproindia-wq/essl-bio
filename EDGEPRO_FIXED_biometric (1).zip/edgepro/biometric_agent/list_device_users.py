"""
list_device_users.py
─────────────────────
STEP 1 of setup. Run this ON THE OFFICE PC / laptop that is on the SAME
network as the eSSL device (192.168.1.39). This machine, not PythonAnywhere,
needs to reach the device — PythonAnywhere cannot see your office LAN.

What it does:
    Connects to the device, pulls every enrolled user (Device User ID + Name),
    and writes them to device_users.xlsx in this same folder.

Then:
    Upload device_users.xlsx to the Django project and run:
        python manage.py link_biometric_ids --file device_users.xlsx --dry-run
    to preview the Emp Code matches, then run it again without --dry-run to save.

Install (one time, on this PC):
    pip install pyzk openpyxl

Usage:
    python list_device_users.py
    python list_device_users.py --ip 192.168.1.39 --port 4370
"""
import argparse
import sys

try:
    from zk import ZK
except ImportError:
    print("Missing dependency. Run:  pip install pyzk")
    sys.exit(1)

import openpyxl


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--ip', default='192.168.1.39', help='Device IP address')
    parser.add_argument('--port', type=int, default=4370, help='Device port (default 4370)')
    parser.add_argument('--timeout', type=int, default=10, help='Connection timeout in seconds')
    parser.add_argument('--out', default='device_users.xlsx', help='Output Excel file')
    args = parser.parse_args()

    print(f"Connecting to {args.ip}:{args.port} ...")
    zk = ZK(args.ip, port=args.port, timeout=args.timeout, password=0, force_udp=False, ommit_ping=False)

    conn = None
    try:
        conn = zk.connect()
        print("Connected. Device info:")
        try:
            print(f"  Firmware: {conn.get_firmware_version()}")
            print(f"  Serial:   {conn.get_serialnumber()}")
        except Exception:
            pass  # not all firmwares expose these, non-fatal

        users = conn.get_users()
        print(f"\nFound {len(users)} enrolled users on the device.\n")

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "device_users"
        ws.append(["User ID", "Name", "Privilege", "Card Number"])

        for u in users:
            ws.append([u.user_id, u.name, u.privilege, getattr(u, 'card', '')])
            print(f"  User ID: {u.user_id:<8} Name: {u.name}")

        wb.save(args.out)
        print(f"\nSaved -> {args.out}")
        print("Next: upload this file into the Django project and run:")
        print(f"  python manage.py link_biometric_ids --file {args.out} --dry-run")

    except Exception as exc:
        print(f"\nConnection FAILED: {exc}")
        print("Checklist:")
        print("  1. Is this PC on the same network/subnet as the device?")
        print("  2. Is the IP address correct? (Check device menu -> Comm/Network settings)")
        print("  3. Is port 4370 open (not blocked by Windows Firewall / office firewall)?")
        print("  4. Some eSSL models need a device 'Comm Key' / password — pass it if so:")
        print("     ZK(ip, port=port, password=<comm_key>)")
        sys.exit(1)
    finally:
        if conn:
            conn.disconnect()


if __name__ == '__main__':
    main()
