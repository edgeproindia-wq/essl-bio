"""
sync_agent.py
──────────────
STEP 3 of setup (after device users are linked via link_biometric_ids).
Run this ON THE OFFICE PC, on the same network as the eSSL device.

What it does, every time it runs:
    1. Connects to the device over TCP (port 4370).
    2. Pulls attendance logs (get_attendance()).
    3. Sends only NEW punches (tracked via a local "last_synced" checkpoint
       file, so re-runs don't resend everything) to the Django API endpoint.
    4. Retries on network failure with backoff; logs everything to
       sync_agent.log in this folder.

Deploy as an automatic, recurring job (no manual intervention) using
Windows Task Scheduler:
    1. Task Scheduler -> Create Task
    2. Trigger: Daily, repeat every 5 minutes, for a duration of 1 day
    3. Action: Start a program
         Program:  C:\\path\\to\\python.exe
         Arguments: C:\\path\\to\\sync_agent.py
    4. "Run whether user is logged on or not"

Install (one time):
    pip install pyzk requests

Configure below (or pass as environment variables / CLI args):
    DEVICE_IP, DEVICE_PORT, API_URL, API_KEY
"""
import argparse
import json
import logging
import os
import sys
import time
from datetime import datetime
from logging.handlers import RotatingFileHandler

try:
    from zk import ZK
except ImportError:
    print("Missing dependency. Run:  pip install pyzk requests")
    sys.exit(1)

try:
    import requests
except ImportError:
    print("Missing dependency. Run:  pip install pyzk requests")
    sys.exit(1)

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CHECKPOINT_FILE = os.path.join(SCRIPT_DIR, 'last_synced.txt')
LOG_FILE = os.path.join(SCRIPT_DIR, 'sync_agent.log')

logger = logging.getLogger('sync_agent')
logger.setLevel(logging.INFO)
_fh = RotatingFileHandler(LOG_FILE, maxBytes=2 * 1024 * 1024, backupCount=3)
_fh.setFormatter(logging.Formatter('[%(asctime)s] %(levelname)s: %(message)s'))
logger.addHandler(_fh)
logger.addHandler(logging.StreamHandler(sys.stdout))

MAX_RETRIES = 3
RETRY_BACKOFF_SECONDS = 5


def load_checkpoint():
    if os.path.exists(CHECKPOINT_FILE):
        with open(CHECKPOINT_FILE, 'r') as f:
            ts = f.read().strip()
            if ts:
                return datetime.fromisoformat(ts)
    return None


def save_checkpoint(dt):
    with open(CHECKPOINT_FILE, 'w') as f:
        f.write(dt.isoformat())


def fetch_punches_from_device(ip, port, timeout):
    zk = ZK(ip, port=port, timeout=timeout, password=0, force_udp=False, ommit_ping=False)
    conn = zk.connect()
    try:
        conn.disable_device()  # pause device fingerprint scanning briefly while reading, avoids read conflicts
        attendances = conn.get_attendance()
        return [
            {
                'user_id': str(a.user_id),
                'timestamp': a.timestamp.isoformat(),
                # pyzk's `punch` field: device-reported type (0=in,1=out,etc.) — pass through as-is
                'punch_type': str(getattr(a, 'punch', 'unknown')),
            }
            for a in attendances
        ]
    finally:
        try:
            conn.enable_device()
        except Exception:
            pass
        conn.disconnect()


def post_to_api(api_url, api_key, device_ip, punches):
    payload = {'device_ip': device_ip, 'punches': punches}
    headers = {'Content-Type': 'application/json', 'X-Biometric-Api-Key': api_key}

    last_exc = None
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            resp = requests.post(api_url, headers=headers, data=json.dumps(payload), timeout=30)
            if resp.status_code == 200:
                return resp.json()
            logger.error("API returned %s: %s", resp.status_code, resp.text[:500])
            if resp.status_code == 401:
                raise RuntimeError("Unauthorized — check BIOMETRIC_API_KEY matches on both sides")
            last_exc = RuntimeError(f"API returned {resp.status_code}")
        except requests.exceptions.RequestException as exc:
            last_exc = exc
            logger.warning("Attempt %d/%d failed: %s", attempt, MAX_RETRIES, exc)
        if attempt < MAX_RETRIES:
            time.sleep(RETRY_BACKOFF_SECONDS * attempt)  # simple exponential-ish backoff
    raise last_exc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--ip', default=os.environ.get('DEVICE_IP', '192.168.1.39'))
    parser.add_argument('--port', type=int, default=int(os.environ.get('DEVICE_PORT', '4370')))
    parser.add_argument('--timeout', type=int, default=10)
    parser.add_argument('--api-url', default=os.environ.get(
        'API_URL', 'https://edgeproindia.pythonanywhere.com/api/biometric/sync/'
    ))
    parser.add_argument('--api-key', default=os.environ.get('BIOMETRIC_API_KEY', ''))
    args = parser.parse_args()

    if not args.api_key:
        logger.error("No API key set. Pass --api-key or set BIOMETRIC_API_KEY env var. Aborting.")
        sys.exit(1)

    logger.info("=== Sync run starting: device=%s:%s ===", args.ip, args.port)

    try:
        all_punches = fetch_punches_from_device(args.ip, args.port, args.timeout)
    except Exception as exc:
        logger.error("Could not read from device: %s", exc)
        sys.exit(1)

    checkpoint = load_checkpoint()
    if checkpoint:
        new_punches = [p for p in all_punches if datetime.fromisoformat(p['timestamp']) > checkpoint]
    else:
        # First ever run: send everything currently on the device once.
        new_punches = all_punches

    logger.info("Device has %d total logs, %d are new since last sync.", len(all_punches), len(new_punches))

    if not new_punches:
        logger.info("Nothing new. Done.")
        return

    try:
        result = post_to_api(args.api_url, args.api_key, args.ip, new_punches)
        logger.info("Sync result: %s", result)
        latest_ts = max(datetime.fromisoformat(p['timestamp']) for p in new_punches)
        save_checkpoint(latest_ts)
        logger.info("Checkpoint updated to %s", latest_ts.isoformat())
    except Exception as exc:
        logger.error("Failed to send punches to API after retries: %s", exc)
        sys.exit(1)

    logger.info("=== Sync run complete ===")


if __name__ == '__main__':
    main()
