# EDGEPRO — Bug Fix Round 2

## The root cause behind most of these bugs

Your project has two parallel UIs sharing one `dashboard.html` file: real,
working Django pages (Attendance, Leave, Complaints — the ones with actual
database records), and a large set of **static demo panels** embedded in the
same file, switched between with client-side JavaScript (`showPage()`).

The **employee sidebar** correctly used `navigateTo()`, which redirects to
the real pages. The **HR/Admin sidebar** called `showPage()` directly for
the same modules, which only swapped to the static demo panel — hardcoded
fake data, buttons that only show a toast, nothing saved. That's why HR/Admin
users would see stale fake data ("10:05 AM · Traffic", "Raj Kumar", etc.)
while regular employees saw real data. **This is fixed**: every nav item that
has a real page now uses `navigateTo()` for both roles, and two missing
routes (Payroll) have been added to the routing table so they stop falling
back to the fake panel too.

## What was fixed, item by item

1. **Check-in/check-out time difference** — now stored as decimal hours but
   *displayed* as "Xh Ym" (e.g. "8h 24m") instead of a raw decimal, matching
   the live duration ticker already on the page.

2. **Quick Access Modules removed** from the dashboard home page.

3. **Daily Work Update — Blockers & Mood removed** — dropped from the model
   (migration `0010_remove_dailyworkupdate_blockers_and_more.py`), the view,
   and the form/table in the template.

4. **Check Out page — Today's Status added** — a status banner (Not Checked
   In / Checked In – Working / Checked Out) always shows at the top,
   regardless of where you are in the check-in/out flow.

5. **HR Monthly Report — full rebuild.** The template expected a calendar,
   stats, and an employee summary table that the view never actually
   supplied (it was rendering broken/empty). Now:
   - Month/year selector covering **Jan 2025 → the current month** (nothing
     beyond the current month is selectable).
   - **Future dates are greyed out**, past dates keep their real
     present/absent/late colour coding.
   - **"Total Days in Month"** replaces the old "Avg Hours" column, plus a
     new summary card for it.

6. **Late Login History** — this was actually working correctly on the real
   page; it looked broken because HR/Admin were being shown the disconnected
   static panel instead (see root cause above). Verified end-to-end: submit
   → appears immediately in the history table.

7. **Leave Management — Apply Leave:**
   - **From/To dates enforced in ascending order** — both client-side (the
     To-Date picker's minimum shifts to match From Date) and server-side
     (rejected with a clear error if violated).
   - **Number of Days is view-only**, calculated automatically from the
     date range — never a free-typed field.
   - **"Applied leave not listed in Recent Leave Status" — fixed.** The view
     was already computing this list; the template just never rendered it.
     It's now a real card showing your last 3 applications and their status.
   - **Draft section added** — Save Draft stores your in-progress form
     (new `LeaveDraft` model), shows a "New draft created" popup, and lists
     all saved drafts with Load/Delete actions.
   - **Cancel → Clear All** — resets every field instead of navigating away.
   - **HR tracking by Employee ID** — `/leave/history/?employee_id=EMP-XXXX`
     lets HR/Admin pull up any employee's leave history by their Employee ID.
   - Fixed hardcoded fake sidebar data too (leave balance numbers, a "Team
     Calendar" widget with invented colleague names, "Raj Kumar" in the nav)
     — all now pull from the real logged-in user and their real balance.

8. **Static data removed for new users** — the dashboard's top stat cards
   used `{{ value|default:12 }}`-style filters, which substitute the fallback
   number whenever the real value is `0` (Django's `default` filter treats 0
   as falsy). A brand-new user with 0 leave taken would have seen "6" days
   used, not their real 0. Switched to `default_if_none` so 0 displays
   correctly. Also fixed a hardcoded `leave_balance = 18` fallback in the
   dashboard view, and the same fake-name sidebar bug across the Leave
   Summary / Daily / Weekly / Monthly Summary pages.

## What's verified

All of the above was tested end-to-end with Django's test client: creating
a user, submitting through each flow, and checking the database and the
rendered page reflect it correctly — not just that the page loads.

## What's out of scope for this round

- The static demo panels inside `dashboard.html` still exist as dead code
  (they're just unreachable now for the modules above). They weren't deleted,
  to keep this change low-risk; they can be removed in a follow-up cleanup
  if you want the file smaller.
- The Leave Summary / Daily / Weekly / Monthly Summary pages still contain
  other hardcoded demo content (team member lists, request avatars) beyond
  the sidebar name fix — say the word if you want those fully wired too.
- HR Review / Resolution complaint pages remain static, as noted previously.

## Deploying

```bash
cd ~/EDGEPRO_FIXED          # your project folder on PythonAnywhere
unzip -o EDGEPRO_FULL_PROJECT_FIXED.zip
workon venv                 # or: source /home/Edgeproindia/venv/bin/activate
pip install -r requirements.txt
python manage.py migrate    # applies migrations 0009, 0010, 0011
python manage.py collectstatic --noinput
```
Then reload the web app from the **Web** tab.
