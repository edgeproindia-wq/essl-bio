@echo off
REM Clean Django Python Cache
REM This removes all __pycache__ directories and .pyc files

echo Cleaning Django Python Cache...
echo.

REM Find and delete all __pycache__ directories
for /d /r . %%d in (__pycache__) do @if exist "%%d" (
    echo Deleting %%d
    rmdir /s /q "%%d"
)

REM Find and delete all .pyc files
for /r . %%f in (*.pyc) do (
    if exist "%%f" (
        echo Deleting %%f
        del /q "%%f"
    )
)

echo.
echo ✓ Cache cleaned successfully!
echo.
pause
