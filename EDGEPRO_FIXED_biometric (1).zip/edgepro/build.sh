#!/usr/bin/env bash
# Build script for deployment platforms (Render, Railway, etc.)
# Set this as the "Build Command" in your platform's dashboard:
#   ./build.sh
set -o errexit

pip install -r requirements.txt

python manage.py collectstatic --noinput
python manage.py migrate
