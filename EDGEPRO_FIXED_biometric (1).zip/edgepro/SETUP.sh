#!/bin/bash

# EDGEPRO Django Setup Script for Mac/Linux
# This script will set up the database and run migrations

echo "============================================"
echo "EDGEPRO - Automated Setup Script"
echo "============================================"
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 is not installed"
    echo "Please install Python 3.8+ using:"
    echo "  Mac: brew install python3"
    echo "  Linux: sudo apt-get install python3"
    exit 1
fi

echo "Step 1: Deleting old database..."
if [ -f db.sqlite3 ]; then
    rm db.sqlite3
    echo "✓ Old database deleted"
else
    echo "ℹ No old database found (fresh install)"
fi
echo ""

echo "Step 2: Cleaning old migrations..."
# Keep __init__.py but delete migration files
cd Essportal/migrations
for file in *.py; do
    if [ "$file" != "__init__.py" ]; then
        rm "$file"
    fi
done
cd ../..
echo "✓ Old migrations cleaned"
echo ""

echo "Step 3: Creating fresh migrations..."
python3 manage.py makemigrations
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to create migrations"
    exit 1
fi
echo "✓ Migrations created successfully"
echo ""

echo "Step 4: Applying migrations to database..."
python3 manage.py migrate
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to apply migrations"
    exit 1
fi
echo "✓ Migrations applied successfully"
echo ""

echo "Step 5: Creating superuser account..."
echo "Please enter your admin credentials:"
echo ""
python3 manage.py createsuperuser
if [ $? -ne 0 ]; then
    echo "WARNING: Superuser creation failed or was skipped"
fi
echo ""

echo "============================================"
echo "✓ Setup Complete!"
echo "============================================"
echo ""
echo "To start the Django server, run:"
echo "  python3 manage.py runserver"
echo ""
echo "Then visit: http://127.0.0.1:8000/"
echo ""
